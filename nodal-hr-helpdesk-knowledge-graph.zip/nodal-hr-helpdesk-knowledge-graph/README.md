# Nodal — HR Helpdesk Knowledge Graph

Full-stack app that turns HR/helpdesk tabular data into a searchable,
chat-queryable knowledge graph.

- **`backend/`** — FastAPI service (Excel/CSV or BigQuery ingestion,
  dynamic knowledge-graph builder, GraphRAG Q&A, admin-configurable LLM
  provider). See `backend/README.md`.
- **`frontend/`** — React (Vite) app with 3 pages: Data Source + Admin
  Settings, an interactive Graph Explorer, and a Chat page. See
  `frontend/README.md`.

## Quick start

```bash
# 1. Backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m spacy download en_core_web_sm   # for extractor="spacy"/"both"
cp .env.example .env                       # edit as needed
python run.py                              # http://localhost:8000

# 2. Frontend (new terminal)
cd frontend
npm install
cp .env.example .env
npm run dev                                # http://localhost:5173
```

Open http://localhost:5173, upload a spreadsheet (or connect BigQuery),
map your columns, build the graph, then explore it or chat with it.

## Configuring the LLM

By default `LLM_PROVIDER=ollama` (matching the original notebook — needs
a local Ollama server). To use a hosted model instead, open the app,
expand **Admin settings** on the Data Source page, pick a provider
(OpenAI / Anthropic / Google Gemini / a local OpenAI-compatible server),
paste an API key if needed, and save — no restart required. Pick "None"
to skip the LLM entirely and get raw graph facts back from chat.

## Connecting BigQuery instead of uploading a file

On the Data Source page, switch to the **BigQuery** tab, provide a
project ID and either a service-account JSON or leave it blank to use
Application Default Credentials, then either point at a `dataset` +
`table` or paste a custom SQL query. Requires
`google-cloud-bigquery`/`db-dtypes` installed on the backend (see
`backend/requirements.txt`).

## Deployment notes

- The frontend calls the backend at same-origin `/api/*` by default; in
  dev this is proxied by Vite (`vite.config.js`), in production put both
  behind the same reverse proxy, or set `VITE_API_BASE_URL` at build time
  and allow that origin in the backend's `CORS_ORIGINS`.
- The backend's session store is pickle-on-disk by default — fine for a
  single-worker/single-instance deployment; swap `app/storage.py` for a
  Redis/Postgres-backed store for multi-worker deployments (see
  `backend/README.md`).
- No authentication is included on either side — add an API-key/OAuth
  dependency (backend) and a login flow (frontend) before exposing this
  beyond a trusted network.
