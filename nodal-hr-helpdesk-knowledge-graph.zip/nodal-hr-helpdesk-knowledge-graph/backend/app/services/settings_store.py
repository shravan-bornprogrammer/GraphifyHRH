"""
Admin-configurable runtime settings.

This backs the "Admin Settings" screen in the frontend: choose the data
source (upload vs. BigQuery) and the LLM provider/model used by
/api/graph/ask, without restarting the service or editing .env. Values are
persisted as JSON under STORAGE_DIR/config/admin_settings.json and seeded
from app/config.py's env-driven defaults on first run.

Secrets (API keys) are stored so the backend can use them, but are always
masked before being returned to the frontend.
"""
from __future__ import annotations

import json
import threading
from typing import Any, Optional

from pydantic import BaseModel, Field

from ..config import settings

_LOCK = threading.Lock()
_PATH = settings.CONFIG_DIR / "admin_settings.json"

MASK = "••••••••"


class LLMProviderConfig(BaseModel):
    provider: str = "ollama"  # ollama | openai | anthropic | gemini | local | none
    model: str = ""
    # Provider-specific connection info (only the relevant fields are used)
    ollama_host: str = settings.OLLAMA_HOST
    ollama_model: str = settings.OLLAMA_MODEL
    openai_api_key: str = ""
    openai_model: str = settings.OPENAI_MODEL
    anthropic_api_key: str = ""
    anthropic_model: str = settings.ANTHROPIC_MODEL
    gemini_api_key: str = ""
    gemini_model: str = settings.GEMINI_MODEL
    local_base_url: str = settings.LOCAL_LLM_BASE_URL
    local_model: str = settings.LOCAL_LLM_MODEL
    local_api_key: str = settings.LOCAL_LLM_API_KEY or ""


class DataSourceConfig(BaseModel):
    mode: str = "upload"  # upload | bigquery
    bigquery_project_id: str = settings.BIGQUERY_PROJECT_ID or ""
    bigquery_dataset: str = ""
    bigquery_table: str = ""
    bigquery_credentials_json: str = ""  # service-account JSON, pasted by the admin


class AdminSettings(BaseModel):
    llm: LLMProviderConfig = Field(default_factory=LLMProviderConfig)
    data_source: DataSourceConfig = Field(default_factory=DataSourceConfig)
    extractor_default: str = "spacy"  # spacy | keybert | both | none
    canonicalize_default: bool = False


_SECRET_FIELDS = {
    "openai_api_key",
    "anthropic_api_key",
    "gemini_api_key",
    "local_api_key",
    "bigquery_credentials_json",
}


def _load() -> AdminSettings:
    if _PATH.exists():
        try:
            data = json.loads(_PATH.read_text(encoding="utf-8"))
            return AdminSettings(**data)
        except Exception:
            pass
    seeded = AdminSettings(
        llm=LLMProviderConfig(
            provider=settings.LLM_PROVIDER,
            openai_api_key=settings.OPENAI_API_KEY or "",
            anthropic_api_key=settings.ANTHROPIC_API_KEY or "",
            gemini_api_key=settings.GEMINI_API_KEY or "",
        ),
    )
    _save(seeded)
    return seeded


def _save(cfg: AdminSettings) -> None:
    _PATH.write_text(cfg.model_dump_json(indent=2), encoding="utf-8")


class SettingsStore:
    def __init__(self) -> None:
        with _LOCK:
            self._cfg = _load()

    def get(self) -> AdminSettings:
        with _LOCK:
            return self._cfg.model_copy(deep=True)

    def update(self, patch: dict[str, Any]) -> AdminSettings:
        with _LOCK:
            current = self._cfg.model_dump()
            for section in ("llm", "data_source"):
                if section in patch and isinstance(patch[section], dict):
                    for k, v in patch[section].items():
                        # Don't clobber a stored secret with a masked placeholder
                        # echoed back by the frontend.
                        if k in _SECRET_FIELDS and v == MASK:
                            continue
                        current[section][k] = v
            for key in ("extractor_default", "canonicalize_default"):
                if key in patch:
                    current[key] = patch[key]
            self._cfg = AdminSettings(**current)
            _save(self._cfg)
            return self._cfg.model_copy(deep=True)

    def public(self) -> dict[str, Any]:
        """Same shape as `get()`, but with secret fields masked for API responses."""
        data = self.get().model_dump()
        for section in ("llm", "data_source"):
            for k in list(data[section].keys()):
                if k in _SECRET_FIELDS and data[section][k]:
                    data[section][k] = MASK
        return data


store = SettingsStore()
