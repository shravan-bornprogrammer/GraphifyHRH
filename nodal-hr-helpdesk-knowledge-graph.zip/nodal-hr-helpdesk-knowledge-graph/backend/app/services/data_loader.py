"""
Dynamic spreadsheet loading + column profiling.

This is what makes the API work on *any* Excel file: instead of assuming
fixed columns like the original notebook ("Ticket Number", "Category", ...),
we read whatever sheet is uploaded, profile every column, and suggest a
role for each one (id / hierarchy / attribute / free-text / ignore). The
caller (a human via Swagger UI, or a frontend) can accept or override the
suggestions before building the graph.
"""
from __future__ import annotations

import io
from pathlib import Path
from typing import Any

import pandas as pd

from ..models import ColumnProfile

TEXT_LEN_THRESHOLD = 40  # avg chars above this => treat as free text, not a category
MAX_CATEGORY_CARDINALITY_RATIO = 0.5  # unique/n_rows above this => probably not categorical


def load_spreadsheet(filename: str, raw_bytes: bytes, sheet_name: str | int | None = 0) -> pd.DataFrame:
    """Load .xlsx/.xls/.csv/.tsv bytes into a DataFrame, whatever the schema."""
    suffix = Path(filename).suffix.lower()
    buf = io.BytesIO(raw_bytes)

    if suffix in (".xlsx", ".xls", ".xlsm"):
        df = pd.read_excel(buf, sheet_name=sheet_name, engine=None)
    elif suffix == ".csv":
        df = pd.read_csv(buf)
    elif suffix == ".tsv":
        df = pd.read_csv(buf, sep="\t")
    else:
        # Best-effort fallback: try Excel first, then CSV.
        try:
            df = pd.read_excel(buf, sheet_name=sheet_name)
        except Exception:
            buf.seek(0)
            df = pd.read_csv(buf)

    # Normalize column names (strip whitespace) but keep them human-readable.
    df.columns = [str(c).strip() for c in df.columns]
    # Drop fully-empty rows/columns that Excel exports often introduce.
    df = df.dropna(axis=0, how="all").dropna(axis=1, how="all")
    df = df.reset_index(drop=True)
    return df


def list_sheet_names(raw_bytes: bytes) -> list[str]:
    xl = pd.ExcelFile(io.BytesIO(raw_bytes))
    return xl.sheet_names


def _suggest_role(series: pd.Series, n_rows: int) -> str:
    non_null = series.dropna()
    if non_null.empty:
        return "ignore"

    n_unique = non_null.nunique()
    uniqueness_ratio = n_unique / max(n_rows, 1)
    is_stringy = pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series)

    # Long free text (comments/descriptions/feedback) -> "text", regardless
    # of how unique it happens to be. Checked before the "id" heuristic so a
    # column of all-unique sentences isn't mistaken for an identifier.
    if is_stringy:
        avg_len = non_null.astype(str).str.len().mean()
        if avg_len is not None and avg_len > TEXT_LEN_THRESHOLD:
            return "text"

    # Looks like a stable unique identifier (e.g. "Ticket Number", "ID").
    if uniqueness_ratio > 0.95 and n_unique > 1:
        return "id"

    # Numeric columns aren't graph node material by default.
    if pd.api.types.is_numeric_dtype(series) and uniqueness_ratio > MAX_CATEGORY_CARDINALITY_RATIO:
        return "ignore"

    if is_stringy:
        if uniqueness_ratio <= MAX_CATEGORY_CARDINALITY_RATIO:
            return "hierarchy"
        return "attribute"

    if pd.api.types.is_datetime64_any_dtype(series):
        return "attribute"

    return "attribute"


def profile_columns(df: pd.DataFrame, max_samples: int = 5) -> list[ColumnProfile]:
    n_rows = len(df)
    profiles: list[ColumnProfile] = []
    for col in df.columns:
        series = df[col]
        samples = series.dropna().astype(str).unique()[:max_samples].tolist()
        profiles.append(
            ColumnProfile(
                name=col,
                dtype=str(series.dtype),
                n_unique=int(series.nunique(dropna=True)),
                n_missing=int(series.isna().sum()),
                sample_values=samples,
                suggested_role=_suggest_role(series, n_rows),  # type: ignore[arg-type]
            )
        )
    return profiles


def preview_rows(df: pd.DataFrame, n: int = 5) -> list[dict[str, Any]]:
    return df.head(n).astype(object).where(pd.notnull(df.head(n)), None).to_dict(orient="records")
