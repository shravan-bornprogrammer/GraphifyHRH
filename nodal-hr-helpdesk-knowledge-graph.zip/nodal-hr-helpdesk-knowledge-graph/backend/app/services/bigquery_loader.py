"""
BigQuery data source.

Lets the app pull tabular HR/helpdesk data directly from a BigQuery table
or an arbitrary SQL query, instead of an uploaded file, using whatever
`google-cloud-bigquery` credentials the admin configured on the Admin
Settings screen (a pasted service-account JSON) or the environment
(Application Default Credentials).

The heavy dependency is imported lazily so the rest of the API keeps
working without `google-cloud-bigquery` installed if BigQuery isn't used.
"""
from __future__ import annotations

import json
import logging
from typing import Optional

import pandas as pd

logger = logging.getLogger(__name__)


class BigQueryError(RuntimeError):
    pass


def _get_client(project_id: Optional[str], credentials_json: Optional[str]):
    try:
        from google.cloud import bigquery
    except ImportError as exc:
        raise BigQueryError(
            "google-cloud-bigquery isn't installed. Run: pip install google-cloud-bigquery db-dtypes"
        ) from exc

    if credentials_json:
        try:
            from google.oauth2 import service_account

            info = json.loads(credentials_json)
            creds = service_account.Credentials.from_service_account_info(info)
            return bigquery.Client(project=project_id or info.get("project_id"), credentials=creds)
        except Exception as exc:
            raise BigQueryError(f"Invalid BigQuery service-account JSON: {exc}") from exc

    # Fall back to Application Default Credentials (e.g. `gcloud auth
    # application-default login`, or a GCE/Cloud Run service identity).
    try:
        return bigquery.Client(project=project_id)
    except Exception as exc:
        raise BigQueryError(
            f"Could not create a BigQuery client (no credentials JSON provided and "
            f"Application Default Credentials weren't found): {exc}"
        ) from exc


def test_connection(project_id: Optional[str], credentials_json: Optional[str]) -> dict:
    client = _get_client(project_id, credentials_json)
    datasets = [d.dataset_id for d in client.list_datasets(max_results=50)]
    return {"project_id": client.project, "datasets": datasets}


def list_tables(project_id: Optional[str], credentials_json: Optional[str], dataset: str) -> list[str]:
    client = _get_client(project_id, credentials_json)
    ref = f"{client.project}.{dataset}"
    return [t.table_id for t in client.list_tables(ref)]


def load_table(
    project_id: Optional[str],
    credentials_json: Optional[str],
    dataset: Optional[str] = None,
    table: Optional[str] = None,
    query: Optional[str] = None,
    row_limit: int = 200_000,
) -> pd.DataFrame:
    """Load either an explicit `dataset.table`, or an arbitrary SQL `query`."""
    client = _get_client(project_id, credentials_json)

    if query:
        sql = query
    elif dataset and table:
        sql = f"SELECT * FROM `{client.project}.{dataset}.{table}` LIMIT {int(row_limit)}"
    else:
        raise BigQueryError("Provide either (dataset AND table) or a custom `query`.")

    try:
        df = client.query(sql).to_dataframe()
    except Exception as exc:
        raise BigQueryError(f"BigQuery query failed: {exc}") from exc

    df.columns = [str(c).strip() for c in df.columns]
    df = df.reset_index(drop=True)
    return df
