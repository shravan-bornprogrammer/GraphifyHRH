"""
Graph-grounded Q&A ("GraphRAG"), generalized from the notebook's
`find_matching_nodes` / `get_context_subgraph` / `ask_hr_bot`.

Node retrieval is now **semantic**: the question and every node's
"<type>: <label>" text are embedded (all-MiniLM-L6-v2 by default, via
`embeddings.py`) and matched by cosine similarity, instead of plain
substring matching — so "comp issues" can retrieve a "Compensation"
node, "sick" can retrieve "Leave", etc. If the embedding model isn't
available (sentence-transformers not installed / model not downloaded),
this degrades gracefully to the original keyword substring matcher so
the endpoint keeps working either way.

The LLM call is pluggable via the admin-configurable `settings_store`
(falls back to `app/config.py` env defaults): ollama / openai /
anthropic / gemini / local (any OpenAI-chat-compatible local server) /
none.
"""
from __future__ import annotations

import logging
import re

import networkx as nx

from ..config import settings
from . import embeddings
from .settings_store import store as admin_store

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = (
    "You are a helpdesk root-cause analysis assistant. Answer ONLY using "
    "the knowledge graph facts given to you. If the answer isn't supported "
    "by the facts, say so plainly. Be concise and specific (name issues, "
    "people, categories mentioned in the facts)."
)


def _find_matching_nodes_keyword(graph: nx.MultiDiGraph, question: str) -> list[str]:
    """Original substring-matching retrieval. Kept as the fallback path for
    when the embedding model isn't available."""
    q = question.lower()
    matches = []
    for n, data in graph.nodes(data=True):
        label = str(data.get("label", n)).lower()
        clean = re.sub(r"^[a-z ]+:", "", label)
        if clean and (clean in q or any(w in q for w in clean.split() if len(w) > 3)):
            matches.append(n)
    return matches


def find_matching_nodes_semantic(
    graph: nx.MultiDiGraph,
    question: str,
    session_id: str,
    top_k: int | None = None,
    min_similarity: float | None = None,
) -> list[tuple[str, float]]:
    """Embedding-based retrieval. Returns (node_id, similarity) pairs, best first."""
    top_k = top_k or settings.MATCH_TOP_K
    min_similarity = settings.MATCH_MIN_SIMILARITY if min_similarity is None else min_similarity

    node_ids, matrix = embeddings.build_node_index(session_id, graph)
    if not node_ids:
        return []

    q_vec = embeddings.encode([question])[0]
    hits = embeddings.cosine_top_k(q_vec, matrix, top_k=top_k, min_similarity=min_similarity)
    return [(node_ids[i], score) for i, score in hits]


def find_matching_nodes(
    graph: nx.MultiDiGraph,
    question: str,
    session_id: str | None = None,
    top_k: int | None = None,
    min_similarity: float | None = None,
) -> tuple[list[str], dict[str, float]]:
    """
    Retrieval entry point used by `ask_graph`. Prefers semantic (embedding)
    search; falls back to keyword substring matching if `session_id` isn't
    given, the embedding model can't be loaded, or semantic search finds
    nothing above the similarity threshold and a keyword match might still
    catch an exact-text mention.

    Returns (matched_node_ids, similarity_by_node_id). similarity_by_node_id
    is empty when the keyword fallback was used (substring matching has no
    natural "score").
    """
    if session_id and embeddings.embeddings_available():
        try:
            hits = find_matching_nodes_semantic(graph, question, session_id, top_k, min_similarity)
            if hits:
                return [node_id for node_id, _score in hits], {node_id: score for node_id, score in hits}
        except Exception as exc:
            logger.warning("Semantic node search failed (%s); falling back to keyword search.", exc)
    return _find_matching_nodes_keyword(graph, question), {}


def get_context_subgraph(graph: nx.MultiDiGraph, matched_nodes: list[str], radius: int = 2):
    nodes: set[str] = set()
    undirected = graph.to_undirected(as_view=True)
    for n in matched_nodes:
        nodes |= set(nx.ego_graph(undirected, n, radius=radius).nodes())
    return graph.subgraph(nodes)


def subgraph_to_facts(sub: nx.MultiDiGraph, max_facts: int = 80) -> list[str]:
    facts = []
    for u, v, data in sub.edges(data=True):
        label = data.get("label", data.get("relation", ""))
        facts.append(f"{u} --{label}--> {v}")
    return facts[:max_facts]


# ---------------------------------------------------------------------------
# LLM backends
# ---------------------------------------------------------------------------
def _call_ollama(prompt: str, model: str | None, cfg) -> str:
    import ollama

    response = ollama.Client(host=cfg.ollama_host or settings.OLLAMA_HOST).chat(
        model=model or cfg.ollama_model or settings.OLLAMA_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return response["message"]["content"]


def _call_openai(prompt: str, model: str | None, cfg) -> str:
    from openai import OpenAI

    api_key = cfg.openai_api_key or settings.OPENAI_API_KEY
    if not api_key:
        raise RuntimeError("No OpenAI API key configured (Admin Settings -> LLM Provider).")
    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=model or cfg.openai_model or settings.OPENAI_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return response.choices[0].message.content or ""


def _call_anthropic(prompt: str, model: str | None, cfg) -> str:
    import anthropic

    api_key = cfg.anthropic_api_key or settings.ANTHROPIC_API_KEY
    if not api_key:
        raise RuntimeError("No Anthropic API key configured (Admin Settings -> LLM Provider).")
    client = anthropic.Anthropic(api_key=api_key)
    response = client.messages.create(
        model=model or cfg.anthropic_model or settings.ANTHROPIC_MODEL,
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text")


def _call_gemini(prompt: str, model: str | None, cfg) -> str:
    import google.generativeai as genai

    api_key = cfg.gemini_api_key or settings.GEMINI_API_KEY
    if not api_key:
        raise RuntimeError("No Gemini API key configured (Admin Settings -> LLM Provider).")
    genai.configure(api_key=api_key)
    gm = genai.GenerativeModel(
        model_name=model or cfg.gemini_model or settings.GEMINI_MODEL,
        system_instruction=SYSTEM_PROMPT,
    )
    response = gm.generate_content(prompt)
    return getattr(response, "text", "") or ""


def _call_local(prompt: str, model: str | None, cfg) -> str:
    """Any OpenAI-chat-compatible local server (LM Studio, vLLM, llama.cpp server, ...)."""
    from openai import OpenAI

    client = OpenAI(
        base_url=cfg.local_base_url or settings.LOCAL_LLM_BASE_URL,
        api_key=cfg.local_api_key or settings.LOCAL_LLM_API_KEY or "not-needed",
    )
    response = client.chat.completions.create(
        model=model or cfg.local_model or settings.LOCAL_LLM_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return response.choices[0].message.content or ""


_PROVIDERS = {
    "ollama": _call_ollama,
    "openai": _call_openai,
    "anthropic": _call_anthropic,
    "gemini": _call_gemini,
    "local": _call_local,
}


def active_provider() -> str:
    return admin_store.get().llm.provider or settings.LLM_PROVIDER


def _complete(prompt: str, model: str | None = None) -> str:
    cfg = admin_store.get().llm
    provider = (cfg.provider or settings.LLM_PROVIDER).lower()
    fn = _PROVIDERS.get(provider)
    if fn is None:
        raise RuntimeError(
            f"LLM provider {provider!r} has no answering backend configured "
            "(choose ollama / openai / anthropic / gemini / local / none in Admin Settings)."
        )
    return fn(prompt, model, cfg)


def ask_graph(
    graph: nx.MultiDiGraph,
    question: str,
    session_id: str | None = None,
    radius: int = 2,
    max_facts: int = 80,
    model: str | None = None,
    top_k: int | None = None,
    min_similarity: float | None = None,
) -> tuple[str, list[str], list[str], dict[str, float]]:
    """Returns (answer, matched_node_ids, facts, match_scores). Node
    retrieval is semantic (embedding similarity) when possible; see
    `find_matching_nodes`. `match_scores` maps node_id -> cosine similarity
    and is empty when the keyword fallback matcher was used instead."""
    matched, match_scores = find_matching_nodes(
        graph, question, session_id=session_id, top_k=top_k, min_similarity=min_similarity
    )
    if not matched:
        return (
            "I couldn't find related nodes in the graph for that question. Try "
            "mentioning a category, topic, keyword, or person that appears in the data.",
            [],
            [],
            {},
        )

    sub = get_context_subgraph(graph, matched, radius=radius)
    facts = subgraph_to_facts(sub, max_facts=max_facts)
    context = "\n".join(facts)

    prompt = (
        f"Knowledge graph facts:\n{context}\n\nQuestion: {question}\nAnswer:"
    )

    provider = active_provider().lower()
    if provider == "none":
        answer = (
            "The LLM provider is set to 'none', so no natural-language answer was "
            f"generated. Here are the {len(facts)} matching graph facts instead."
        )
    else:
        answer = _complete(prompt, model)

    return answer, matched, facts, match_scores
