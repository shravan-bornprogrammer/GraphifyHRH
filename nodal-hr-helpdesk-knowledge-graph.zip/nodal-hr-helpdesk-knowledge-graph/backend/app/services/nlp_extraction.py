"""
NLP extraction utilities, generalized from the notebook's spaCy/KeyBERT/
sentence-transformers cells.

Every heavy dependency is imported lazily and wrapped in a try/except so the
API still starts (and still works with extractor="none" or "spacy") on a
machine that doesn't have KeyBERT / sentence-transformers installed, or that
can't reach the model hub. Models are cached as module-level singletons so
they're loaded once per process, not once per request.
"""
from __future__ import annotations

import functools
import logging
from typing import Iterable

from ..config import settings

logger = logging.getLogger(__name__)

KEEP_ENTITY_LABELS = {"PERSON", "ORG", "GPE", "DATE", "PRODUCT"}


# ---------------------------------------------------------------------------
# spaCy: concept / entity extraction (notebook cells 1 & 11)
# ---------------------------------------------------------------------------
@functools.lru_cache(maxsize=1)
def _get_spacy_nlp():
    import spacy

    try:
        return spacy.load(settings.SPACY_MODEL)
    except OSError as exc:
        raise RuntimeError(
            f"spaCy model '{settings.SPACY_MODEL}' is not installed. "
            f"Run: python -m spacy download {settings.SPACY_MODEL}"
        ) from exc


def spacy_available() -> bool:
    try:
        _get_spacy_nlp()
        return True
    except Exception:
        return False


def extract_concepts(text: str) -> set[str]:
    """Named entities (people/orgs/dates/...) + noun-chunk concepts from free text."""
    if not text or not isinstance(text, str):
        return set()
    nlp = _get_spacy_nlp()
    doc = nlp(text)
    concepts: set[str] = set()

    for ent in doc.ents:
        if ent.label_ in KEEP_ENTITY_LABELS:
            concepts.add(ent.text.strip())

    for chunk in doc.noun_chunks:
        cleaned = chunk.text.lower().strip()
        if len(cleaned) > 2 and not chunk.root.is_stop:
            concepts.add(cleaned)

    return concepts


def extract_people(text: str) -> list[str]:
    if not text or not isinstance(text, str):
        return []
    nlp = _get_spacy_nlp()
    doc = nlp(text)
    return [ent.text for ent in doc.ents if ent.label_ == "PERSON"]


# ---------------------------------------------------------------------------
# KeyBERT: short "issue phrase" extraction (notebook cell 9)
# ---------------------------------------------------------------------------
@functools.lru_cache(maxsize=1)
def _get_keybert_model():
    from keybert import KeyBERT

    return KeyBERT(model=settings.EMBEDDING_MODEL)


def keybert_available() -> bool:
    try:
        _get_keybert_model()
        return True
    except Exception:
        return False


def extract_issue_keybert(text: str, top_n: int = 1) -> str:
    if not text:
        return ""
    try:
        model = _get_keybert_model()
        keywords = model.extract_keywords(
            text, keyphrase_ngram_range=(2, 4), stop_words="english", top_n=top_n
        )
        return keywords[0][0].title() if keywords else text[:40].title()
    except Exception as exc:
        logger.warning("KeyBERT unavailable (%s); falling back to a text snippet.", exc)
        return text[:40].title()


# ---------------------------------------------------------------------------
# Canonicalization: cluster near-duplicate phrases (notebook cell 10)
# ---------------------------------------------------------------------------
@functools.lru_cache(maxsize=1)
def _get_embedder():
    from sentence_transformers import SentenceTransformer

    return SentenceTransformer(settings.EMBEDDING_MODEL)


def canonicalize_phrases(
    phrases: Iterable[str], distance_threshold: float | None = None
) -> dict[str, str]:
    """
    Map every phrase to a canonical representative of its semantic cluster.
    Falls back to the identity mapping if embeddings aren't available.
    """
    unique_phrases = sorted(set(p for p in phrases if p))
    if len(unique_phrases) <= 1:
        return {p: p for p in unique_phrases}

    threshold = distance_threshold or settings.CANONICALIZE_DISTANCE_THRESHOLD

    try:
        from sklearn.cluster import AgglomerativeClustering

        embedder = _get_embedder()
        embeddings = embedder.encode(unique_phrases, normalize_embeddings=True)

        clustering = AgglomerativeClustering(
            n_clusters=None,
            distance_threshold=threshold,
            metric="cosine",
            linkage="average",
        ).fit(embeddings)

        clusters: dict[int, list[str]] = {}
        for phrase, label in zip(unique_phrases, clustering.labels_):
            clusters.setdefault(int(label), []).append(phrase)

        mapping: dict[str, str] = {}
        for phrases_in_cluster in clusters.values():
            canonical = min(phrases_in_cluster, key=len)
            for p in phrases_in_cluster:
                mapping[p] = canonical
        return mapping
    except Exception as exc:
        logger.warning(
            "Canonicalization unavailable (%s); using identity mapping "
            "(each phrase stays its own node).", exc,
        )
        return {p: p for p in unique_phrases}
