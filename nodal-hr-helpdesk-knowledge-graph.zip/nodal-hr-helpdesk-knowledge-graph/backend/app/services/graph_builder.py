"""
Dynamic knowledge-graph builder.

Generalizes the notebook's `build_combined_graph` / `build_kg_dynamic`
(which hard-coded "Category"/"Topic"/"Subtopic"/"Ticket Number"/etc.) into
something driven entirely by the column mapping the caller supplies, so it
works on any Excel/CSV:

    row-node --HAS_<HIERARCHY[0]>--> h0 --HAS_<HIERARCHY[1]>--> h1 --> ...
    row-node --HAS_<ATTRIBUTE>-->   attribute value node
    row-node --MENTIONS-->          NLP-derived concept/keyword node
    row-node --INVOLVES-->          Person node (from free text, via spaCy)

Every edge/node is tagged with a `type` so the visualizer can color/filter
by role, exactly like the notebook's COLOR_MAP did for its fixed schema.
"""
from __future__ import annotations

import logging
from typing import Any

import networkx as nx
import pandas as pd

from ..models import GraphBuildRequest
from . import nlp_extraction as nlpx

logger = logging.getLogger(__name__)


def _row_label(row: pd.Series, req: GraphBuildRequest, idx: int) -> str:
    if req.node_label_column and req.node_label_column in row:
        val = row[req.node_label_column]
        if pd.notna(val):
            return str(val)
    if req.id_column and req.id_column in row:
        val = row[req.id_column]
        if pd.notna(val):
            return str(val)
    return f"Row-{idx}"


def _safe(val: Any) -> str | None:
    if val is None:
        return None
    if isinstance(val, float) and pd.isna(val):
        return None
    s = str(val).strip()
    return s or None


def build_graph(df: pd.DataFrame, req: GraphBuildRequest) -> tuple[nx.MultiDiGraph, dict[str, int]]:
    G = nx.MultiDiGraph()

    def add_node(node_id: str, ntype: str, **attrs) -> None:
        if G.has_node(node_id):
            return
        G.add_node(node_id, type=ntype, label=node_id.split(":", 1)[-1], **attrs)

    # --- Optional: precompute NLP extraction across all text columns first,
    # so canonicalization operates on the full corpus of phrases (matches
    # the notebook's dedupe-then-cluster approach in build_kg_dynamic).
    issue_by_row_col: dict[tuple[int, str], str] = {}
    if req.text_columns and req.extractor in ("keybert", "both") and nlpx.keybert_available():
        raw_phrases: list[str] = []
        for col in req.text_columns:
            if col not in df.columns:
                continue
            for idx, val in df[col].items():
                text = _safe(val)
                if not text:
                    continue
                phrase = nlpx.extract_issue_keybert(text)
                issue_by_row_col[(idx, col)] = phrase
                raw_phrases.append(phrase)

        canonical_map = (
            nlpx.canonicalize_phrases(raw_phrases) if req.canonicalize and raw_phrases else {}
        )
        if canonical_map:
            for key, phrase in issue_by_row_col.items():
                issue_by_row_col[key] = canonical_map.get(phrase, phrase)

    for idx, row in df.iterrows():
        row_label = _row_label(row, req, idx)
        row_node = f"Row:{row_label}"
        add_node(row_node, "Row")

        # --- Hierarchy chain: row -> h0 -> h1 -> h2 -> ...
        prev_node = row_node
        prev_type_name = "Row"
        for depth, col in enumerate(req.hierarchy_columns):
            if col not in df.columns:
                continue
            value = _safe(row.get(col))
            if value is None:
                break  # stop the chain at the first missing level
            node_id = f"{col}:{value}"
            add_node(node_id, col)
            relation = "HAS_" if depth == 0 else "HAS_"
            edge_label = f"HAS_{col.upper().replace(' ', '_')}"
            G.add_edge(prev_node, node_id, label=edge_label, relation=edge_label)
            prev_node = node_id
            prev_type_name = col

        # --- Flat attribute columns (Intent, Sentiment, date, owner, ...)
        for col in req.attribute_columns:
            if col not in df.columns:
                continue
            value = _safe(row.get(col))
            if value is None:
                continue
            node_id = f"{col}:{value}"
            add_node(node_id, col)
            edge_label = f"HAS_{col.upper().replace(' ', '_')}"
            G.add_edge(row_node, node_id, label=edge_label, relation=edge_label)

        # --- Free text columns -> NLP-derived nodes
        for col in req.text_columns:
            if col not in df.columns:
                continue
            text = _safe(row.get(col))
            if not text:
                continue

            if req.extractor in ("spacy", "both") and nlpx.spacy_available():
                for concept in nlpx.extract_concepts(text):
                    node_id = f"Keyword:{concept}"
                    add_node(node_id, "Keyword")
                    G.add_edge(row_node, node_id, label="MENTIONS", relation="MENTIONS")

            if req.extractor in ("keybert", "both"):
                phrase = issue_by_row_col.get((idx, col))
                if phrase:
                    node_id = f"Issue:{phrase}"
                    add_node(node_id, "Issue")
                    G.add_edge(row_node, node_id, label="ROOT_CAUSE", relation="ROOT_CAUSE")

            if req.extract_people and nlpx.spacy_available():
                for person in nlpx.extract_people(text):
                    node_id = f"Person:{person}"
                    add_node(node_id, "Person")
                    G.add_edge(row_node, node_id, label="INVOLVES", relation="INVOLVES")

    node_type_counts: dict[str, int] = {}
    for _, data in G.nodes(data=True):
        t = data.get("type", "Other")
        node_type_counts[t] = node_type_counts.get(t, 0) + 1

    logger.info("Built graph: %d nodes, %d edges", G.number_of_nodes(), G.number_of_edges())
    return G, node_type_counts
