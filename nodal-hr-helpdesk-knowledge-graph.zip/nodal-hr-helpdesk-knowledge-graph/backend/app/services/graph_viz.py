"""
Searchable interactive graph visualization.

This is a generalization of the notebook's `render_graph_with_search`: the
notebook hard-coded a COLOR_MAP for its 8 fixed node types ("Category",
"Topic", ... "Person"). Here we auto-assign colors to whatever node types
actually appear in the graph (any hierarchy/attribute column name becomes
its own type), so it works for any schema. Rendering is still vis-network
via CDN, with the same search/highlight/focus UX as the original.
"""
from __future__ import annotations

import json
from itertools import cycle
from typing import Optional

import networkx as nx

_PALETTE = [
    "#4C72B0", "#55A868", "#8172B2", "#CCB974", "#C44E52",
    "#DD8452", "#64B5CD", "#9d4edd", "#e76f51", "#06d6a0",
    "#ef476f", "#8ecae6", "#ffb703", "#fb8500", "#118ab2",
]
DIM_COLOR = "#e0e0e0"


def _build_color_map(node_types: set[str]) -> dict[str, str]:
    color_map = {"Row": "#999999"}  # keep the row/record node neutral-gray by default
    palette_iter = cycle(_PALETTE)
    for t in sorted(node_types):
        if t not in color_map:
            color_map[t] = next(palette_iter)
    return color_map


def graph_to_json(
    graph: nx.MultiDiGraph,
    subset_nodes: Optional[list[str]] = None,
    limit: Optional[int] = None,
) -> dict:
    """
    Serialize the graph (or an induced subgraph) into plain nodes/edges JSON
    for the React frontend's interactive graph explorer & chat panel — the
    JSON equivalent of `render_graph_html`, without the embedded viewer.
    """
    sub = graph.subgraph(subset_nodes) if subset_nodes else graph
    node_types = {data.get("type", "Other") for _, data in sub.nodes(data=True)}
    color_map = _build_color_map(node_types)

    nodes = []
    for i, (n, data) in enumerate(sub.nodes(data=True)):
        if limit and i >= limit:
            break
        ntype = data.get("type", "Other")
        nodes.append({
            "id": n,
            "label": data.get("label", n.split(":", 1)[-1]),
            "type": ntype,
            "color": color_map.get(ntype, "#CCCCCC"),
            "degree": sub.degree(n) if sub.has_node(n) else 0,
        })
    kept_ids = {n["id"] for n in nodes}

    edges = []
    for i, (u, v, data) in enumerate(sub.edges(data=True)):
        if u not in kept_ids or v not in kept_ids:
            continue
        edges.append({
            "id": f"e{i}",
            "source": u,
            "target": v,
            "label": data.get("label", data.get("relation", "")),
        })

    return {
        "nodes": nodes,
        "edges": edges,
        "node_types": sorted(color_map.keys()),
        "color_map": color_map,
        "n_nodes_total": sub.number_of_nodes(),
        "n_edges_total": sub.number_of_edges(),
    }


def render_graph_html(
    graph: nx.MultiDiGraph,
    title: str = "Knowledge Graph",
    subset_nodes: Optional[list[str]] = None,
) -> str:
    sub = graph.subgraph(subset_nodes) if subset_nodes else graph
    node_types = {data.get("type", "Other") for _, data in sub.nodes(data=True)}
    color_map = _build_color_map(node_types)

    vis_nodes = []
    for n, data in sub.nodes(data=True):
        ntype = data.get("type", "Other")
        vis_nodes.append({
            "id": n,
            "label": data.get("label", n.split(":", 1)[-1]),
            "type": ntype,
            "color": color_map.get(ntype, "#CCCCCC"),
            "title": f"{ntype}: {data.get('label', n)}",
        })

    vis_edges = []
    for i, (u, v, data) in enumerate(sub.edges(data=True)):
        vis_edges.append({
            "id": f"e{i}",
            "from": u,
            "to": v,
            "label": data.get("label", data.get("relation", "")),
            "arrows": "to",
            "color": {"color": "#848484"},
            "font": {"align": "middle", "size": 10},
        })

    legend_items = "".join(
        f'<span class="legend-item"><span class="legend-dot" '
        f'style="background:{color_map[t]}"></span>{t}</span>'
        for t in sorted(color_map)
    )

    nodes_json = json.dumps(vis_nodes)
    edges_json = json.dumps(vis_edges)
    dim_color_json = json.dumps(DIM_COLOR)

    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="https://unpkg.com/vis-network@9.1.9/standalone/umd/vis-network.min.js"></script>
<style>
  body {{ font-family: Arial, sans-serif; margin: 0; }}
  #search-bar {{
    padding: 10px; background: #222; display: flex; gap: 8px; align-items: center; flex-wrap: wrap;
  }}
  #search-bar input {{
    flex: 1; min-width: 200px; padding: 8px; font-size: 14px; border-radius: 4px; border: none;
  }}
  #search-bar button {{
    padding: 8px 14px; border: none; border-radius: 4px; background: #555; color: white; cursor: pointer;
  }}
  #match-count {{ color: #ddd; font-size: 13px; min-width: 140px; }}
  #legend {{ padding: 6px 10px; background: #fafafa; border-bottom: 1px solid #ccc; font-size: 12px; }}
  .legend-item {{ margin-right: 14px; white-space: nowrap; }}
  .legend-dot {{
    display: inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: 4px;
  }}
  #results-panel {{
    max-height: 160px; overflow-y: auto; background: #fafafa; border-bottom: 1px solid #ccc;
    display: none; padding: 6px 10px; font-size: 13px;
  }}
  #results-panel div {{ padding: 3px 0; cursor: pointer; }}
  #results-panel div:hover {{ text-decoration: underline; color: #2b6cb0; }}
  #mynetwork {{ width: 100%; height: 780px; border-top: 1px solid #ccc; }}
</style>
</head>
<body>

<div id="search-bar">
  <input id="search-input" type="text" placeholder="Search nodes or edges..." />
  <button onclick="clearSearch()">Clear</button>
  <span id="match-count"></span>
</div>
<div id="legend">{legend_items}</div>
<div id="results-panel"></div>
<div id="mynetwork"></div>

<script>
  const rawNodes = {nodes_json};
  const rawEdges = {edges_json};
  const DIM_COLOR = {dim_color_json};

  const originalNodeColor = {{}};
  const originalEdgeColor = {{}};
  rawNodes.forEach(n => originalNodeColor[n.id] = n.color);
  rawEdges.forEach(e => originalEdgeColor[e.id] = e.color.color);

  const nodesDataSet = new vis.DataSet(rawNodes);
  const edgesDataSet = new vis.DataSet(rawEdges);

  const container = document.getElementById("mynetwork");
  const data = {{ nodes: nodesDataSet, edges: edgesDataSet }};
  const options = {{
    physics: {{ stabilization: true, barnesHut: {{ gravitationalConstant: -8000, springLength: 120 }} }},
    interaction: {{ hover: true, tooltipDelay: 100 }},
    edges: {{ smooth: {{ type: "dynamic" }} }},
    nodes: {{ shape: "dot", size: 16, font: {{ size: 13 }} }},
  }};
  const network = new vis.Network(container, data, options);

  const input = document.getElementById("search-input");
  const countLabel = document.getElementById("match-count");
  const resultsPanel = document.getElementById("results-panel");

  function resetHighlight() {{
    nodesDataSet.update(rawNodes.map(n => ({{
      id: n.id, color: originalNodeColor[n.id], opacity: 1,
      font: {{ color: "#000000", size: 13 }}
    }})));
    edgesDataSet.update(rawEdges.map(e => ({{
      id: e.id, color: {{ color: originalEdgeColor[e.id] }}, width: 1
    }})));
    resultsPanel.style.display = "none";
    countLabel.textContent = "";
  }}

  function clearSearch() {{
    input.value = "";
    resetHighlight();
  }}

  function runSearch() {{
    const q = input.value.trim().toLowerCase();
    if (!q) {{ resetHighlight(); return; }}

    const matchedNodeIds = new Set(
      rawNodes.filter(n => n.label.toLowerCase().includes(q) || n.type.toLowerCase().includes(q))
              .map(n => n.id)
    );
    const matchedEdges = rawEdges.filter(e => (e.label || "").toLowerCase().includes(q));
    const matchedEdgeIds = new Set(matchedEdges.map(e => e.id));

    matchedEdges.forEach(e => {{ matchedNodeIds.add(e.from); matchedNodeIds.add(e.to); }});

    nodesDataSet.update(rawNodes.map(n => {{
      const isMatch = matchedNodeIds.has(n.id);
      return {{
        id: n.id,
        color: isMatch ? originalNodeColor[n.id] : DIM_COLOR,
        font: {{ color: isMatch ? "#000000" : "#cccccc", size: 13 }}
      }};
    }}));
    edgesDataSet.update(rawEdges.map(e => {{
      const isMatch = matchedEdgeIds.has(e.id);
      return {{
        id: e.id,
        color: {{ color: isMatch ? "#d62728" : DIM_COLOR }},
        width: isMatch ? 3 : 1
      }};
    }}));

    countLabel.textContent = matchedNodeIds.size + " node(s), " + matchedEdgeIds.size + " edge(s) found";

    resultsPanel.innerHTML = "";
    if (matchedNodeIds.size > 0 || matchedEdgeIds.size > 0) {{
      resultsPanel.style.display = "block";
      [...matchedNodeIds].forEach(id => {{
        const div = document.createElement("div");
        div.textContent = "\\u25CF Node: " + id;
        div.onclick = () => {{
          network.focus(id, {{ scale: 1.6, animation: true }});
          network.selectNodes([id]);
        }};
        resultsPanel.appendChild(div);
      }});
      matchedEdges.forEach(e => {{
        const div = document.createElement("div");
        div.textContent = "\\u2192 Edge: " + e.from + " --[" + e.label + "]--> " + e.to;
        div.onclick = () => {{
          network.fit({{ nodes: [e.from, e.to], animation: true }});
          network.selectEdges([e.id]);
        }};
        resultsPanel.appendChild(div);
      }});
    }} else {{
      resultsPanel.style.display = "none";
    }}

    if (matchedNodeIds.size > 0) {{
      network.fit({{ nodes: [...matchedNodeIds], animation: true }});
    }}
  }}

  input.addEventListener("input", runSearch);
</script>
</body>
</html>
"""
