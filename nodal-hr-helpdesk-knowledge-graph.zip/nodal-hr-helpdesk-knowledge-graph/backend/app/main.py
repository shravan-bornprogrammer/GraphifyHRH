"""
Helpdesk Knowledge Graph API
============================

A FastAPI service that turns HR/helpdesk tabular data (Excel/CSV upload OR
a BigQuery table/query) into a searchable, chat-queryable knowledge graph.

Typical flow (matches the 3-page React frontend):
  Page 1 - Data source + Admin Settings
    GET  /api/admin/settings            -> current LLM/data-source config
    POST /api/admin/settings            -> update it (provider, keys, BigQuery)
    POST /api/admin/llm/test            -> sanity-check the configured LLM
    POST /api/upload                    -> upload a spreadsheet
    POST /api/connect/bigquery/test     -> validate BigQuery credentials
    POST /api/connect/bigquery          -> load a BigQuery table/query as a session
    POST /api/graph/build               -> build the knowledge graph

  Page 2 - Interactive graph explorer
    GET  /api/graph/data/{id}           -> nodes/edges JSON (search/filter)
    GET  /api/graph/node/{id}/{node_id} -> a node's immediate neighborhood
    GET  /api/graph/view/{id}           -> standalone HTML view (optional)

  Page 3 - Chat
    POST /api/graph/ask                 -> ask a question, get an answer +
                                            the exact matched subgraph (JSON)

Run with:  uvicorn app.main:app --reload
"""
from __future__ import annotations

import logging

from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from .config import settings
from .models import (
    AdminSettingsUpdate,
    AskRequest,
    AskResponse,
    BigQueryConnectRequest,
    BigQueryTestRequest,
    ErrorResponse,
    GraphBuildRequest,
    GraphBuildResponse,
    GraphData,
    LLMTestRequest,
    LLMTestResponse,
    SessionInfo,
    UploadResponse,
)
from .services import bigquery_loader, data_loader, embeddings, graph_builder, graph_viz, llm_qa
from .services.settings_store import MASK, store as admin_store
from .storage import store

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("helpdesk_graph_api")

app = FastAPI(
    title="Helpdesk Knowledge Graph API",
    description=__doc__,
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health", tags=["meta"])
def health() -> dict:
    return {
        "status": "ok",
        "llm_provider": llm_qa.active_provider(),
        "semantic_search": embeddings.embeddings_available(),
    }


# ---------------------------------------------------------------------------
# Admin settings: data source + LLM provider configuration
# ---------------------------------------------------------------------------
@app.get("/api/admin/settings", tags=["admin"])
def get_admin_settings() -> dict:
    return admin_store.public()


@app.put("/api/admin/settings", tags=["admin"])
@app.post("/api/admin/settings", tags=["admin"])
def update_admin_settings(patch: AdminSettingsUpdate) -> dict:
    updated = admin_store.update(patch.model_dump(exclude_none=True))
    return admin_store.public()


@app.get("/api/admin/llm-providers", tags=["admin"])
def list_llm_providers() -> dict:
    cfg = admin_store.get().llm
    return {
        "current": cfg.provider,
        "providers": [
            {"id": "ollama", "label": "Ollama (local)", "configured": True, "model": cfg.ollama_model},
            {"id": "openai", "label": "OpenAI", "configured": bool(cfg.openai_api_key or settings.OPENAI_API_KEY), "model": cfg.openai_model},
            {"id": "anthropic", "label": "Anthropic Claude", "configured": bool(cfg.anthropic_api_key or settings.ANTHROPIC_API_KEY), "model": cfg.anthropic_model},
            {"id": "gemini", "label": "Google Gemini", "configured": bool(cfg.gemini_api_key or settings.GEMINI_API_KEY), "model": cfg.gemini_model},
            {"id": "local", "label": "Local (OpenAI-compatible server)", "configured": True, "model": cfg.local_model},
            {"id": "none", "label": "None (facts only, no LLM)", "configured": True, "model": ""},
        ],
    }


@app.post("/api/admin/llm/test", response_model=LLMTestResponse, tags=["admin"])
def test_llm(req: LLMTestRequest) -> LLMTestResponse:
    cfg = admin_store.get().llm
    provider = (req.provider or cfg.provider or "none").lower()
    if provider == "none":
        return LLMTestResponse(provider=provider, ok=True, reply="(no LLM configured — facts-only mode)")
    try:
        fn = llm_qa._PROVIDERS.get(provider)
        if fn is None:
            raise RuntimeError(f"Unknown provider {provider!r}")
        reply = fn(req.prompt, None, cfg)
        return LLMTestResponse(provider=provider, ok=True, reply=reply)
    except Exception as exc:
        logger.warning("LLM test failed for provider=%s: %s", provider, exc)
        return LLMTestResponse(provider=provider, ok=False, error=str(exc))


# ---------------------------------------------------------------------------
# 1a. Upload any spreadsheet
# ---------------------------------------------------------------------------
@app.post(
    "/api/upload",
    response_model=UploadResponse,
    responses={400: {"model": ErrorResponse}},
    tags=["data"],
)
async def upload_file(
    file: UploadFile = File(...),
    sheet_name: str | None = Query(
        default=None, description="Sheet name/index for multi-sheet Excel files."
    ),
) -> UploadResponse:
    raw = await file.read()
    if len(raw) > settings.MAX_UPLOAD_BYTES:
        raise HTTPException(413, f"File exceeds max size of {settings.MAX_UPLOAD_BYTES} bytes.")

    sheet: str | int | None = sheet_name
    if sheet_name is not None and sheet_name.isdigit():
        sheet = int(sheet_name)

    try:
        df = data_loader.load_spreadsheet(file.filename or "upload.xlsx", raw, sheet_name=sheet or 0)
    except Exception as exc:
        logger.exception("Failed to parse uploaded file")
        raise HTTPException(400, f"Could not parse '{file.filename}' as a spreadsheet: {exc}") from exc

    if df.empty:
        raise HTTPException(400, "The uploaded file has no usable rows/columns.")

    session = store.create(filename=file.filename or "upload.xlsx", df=df)
    columns = data_loader.profile_columns(df)

    return UploadResponse(
        session_id=session.session_id,
        filename=session.filename,
        n_rows=len(df),
        n_columns=len(df.columns),
        columns=columns,
        preview=data_loader.preview_rows(df),
    )


@app.get("/api/upload/{session_id}/sheets", tags=["data"])
async def list_sheets(session_id: str) -> dict:
    """Convenience endpoint if you need to re-inspect available sheets of an original file."""
    path = settings.UPLOAD_DIR / f"{session_id}.pkl"
    if not path.exists():
        raise HTTPException(404, "Unknown session_id.")
    return {"note": "Re-upload with ?sheet_name=<name> to load a specific sheet."}


# ---------------------------------------------------------------------------
# 1b. BigQuery data source
# ---------------------------------------------------------------------------
@app.post("/api/connect/bigquery/test", tags=["data"])
def test_bigquery(req: BigQueryTestRequest) -> dict:
    cfg = admin_store.get().data_source
    project_id = req.project_id or cfg.bigquery_project_id or None
    creds = req.credentials_json or (
        cfg.bigquery_credentials_json if cfg.bigquery_credentials_json != MASK else None
    )
    try:
        return bigquery_loader.test_connection(project_id, creds)
    except bigquery_loader.BigQueryError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.get("/api/connect/bigquery/tables", tags=["data"])
def bigquery_tables(dataset: str) -> dict:
    cfg = admin_store.get().data_source
    creds = cfg.bigquery_credentials_json if cfg.bigquery_credentials_json != MASK else None
    try:
        tables = bigquery_loader.list_tables(cfg.bigquery_project_id or None, creds, dataset)
        return {"dataset": dataset, "tables": tables}
    except bigquery_loader.BigQueryError as exc:
        raise HTTPException(400, str(exc)) from exc


@app.post(
    "/api/connect/bigquery",
    response_model=UploadResponse,
    responses={400: {"model": ErrorResponse}},
    tags=["data"],
)
def connect_bigquery(req: BigQueryConnectRequest) -> UploadResponse:
    cfg = admin_store.get().data_source
    project_id = req.project_id or cfg.bigquery_project_id or None
    creds = req.credentials_json or (
        cfg.bigquery_credentials_json if cfg.bigquery_credentials_json != MASK else None
    )

    try:
        df = bigquery_loader.load_table(
            project_id,
            creds,
            dataset=req.dataset,
            table=req.table,
            query=req.query,
            row_limit=req.row_limit,
        )
    except bigquery_loader.BigQueryError as exc:
        raise HTTPException(400, str(exc)) from exc

    if df.empty:
        raise HTTPException(400, "The BigQuery query returned no rows.")

    label = req.query and "bigquery:query" or f"bigquery:{req.dataset}.{req.table}"
    session = store.create(filename=label, df=df)
    columns = data_loader.profile_columns(df)

    return UploadResponse(
        session_id=session.session_id,
        filename=session.filename,
        n_rows=len(df),
        n_columns=len(df.columns),
        columns=columns,
        preview=data_loader.preview_rows(df),
    )


# ---------------------------------------------------------------------------
# 2. Build the knowledge graph from a dynamic column mapping
# ---------------------------------------------------------------------------
@app.post(
    "/api/graph/build",
    response_model=GraphBuildResponse,
    responses={404: {"model": ErrorResponse}, 400: {"model": ErrorResponse}},
    tags=["graph"],
)
def build_graph(req: GraphBuildRequest) -> GraphBuildResponse:
    try:
        session = store.get(req.session_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc

    all_requested = set(req.hierarchy_columns) | set(req.attribute_columns) | set(req.text_columns)
    unknown = all_requested - set(session.df.columns)
    if unknown:
        raise HTTPException(400, f"Unknown column(s): {sorted(unknown)}")

    try:
        graph, node_type_counts = graph_builder.build_graph(session.df, req)
    except Exception as exc:
        logger.exception("Graph build failed")
        raise HTTPException(400, f"Failed to build graph: {exc}") from exc

    store.set_graph(req.session_id, graph, meta=req.model_dump())
    # A rebuilt graph invalidates any cached semantic (embedding) node index
    # for this session, so /api/graph/ask re-embeds against the new nodes.
    embeddings.invalidate(req.session_id)

    # Persist a static HTML view right away so /api/graph/view is instant.
    html = graph_viz.render_graph_html(graph, title=f"Knowledge Graph — {session.filename}")
    (settings.HTML_DIR / f"{req.session_id}.html").write_text(html, encoding="utf-8")

    return GraphBuildResponse(
        session_id=req.session_id,
        n_nodes=graph.number_of_nodes(),
        n_edges=graph.number_of_edges(),
        node_types=node_type_counts,
        view_url=f"/api/graph/view/{req.session_id}",
        message="Graph built. Open the Graph Explorer page for the interactive, searchable graph.",
    )


# ---------------------------------------------------------------------------
# 3. Graph data for the React frontend (JSON, not the embedded HTML view)
# ---------------------------------------------------------------------------
@app.get(
    "/api/graph/data/{session_id}",
    response_model=GraphData,
    responses={404: {"model": ErrorResponse}},
    tags=["graph"],
)
def graph_data(
    session_id: str,
    q: str | None = Query(default=None, description="Filter: only nodes/edges whose label matches."),
    node_type: str | None = Query(default=None, description="Filter: only this node type (repeatable via comma-list)."),
    limit: int = Query(default=1500, ge=1, le=20000),
) -> GraphData:
    try:
        session = store.get(session_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc
    if session.graph is None:
        raise HTTPException(404, "No graph built yet for this session. POST /api/graph/build first.")

    graph = session.graph
    subset = None
    if q or node_type:
        wanted_types = set(t.strip() for t in node_type.split(",")) if node_type else None
        ql = q.lower() if q else None
        subset = [
            n for n, data in graph.nodes(data=True)
            if (not wanted_types or data.get("type") in wanted_types)
            and (not ql or ql in str(data.get("label", n)).lower())
        ]
        # Pull in each matched node's direct neighbors so the filtered view
        # still shows connecting context, not isolated dots.
        expanded = set(subset)
        undirected = graph.to_undirected(as_view=True)
        for n in subset:
            expanded.update(undirected.neighbors(n))
        subset = list(expanded)

    payload = graph_viz.graph_to_json(graph, subset_nodes=subset, limit=limit)
    return GraphData(**payload)


@app.get(
    "/api/graph/node/{session_id}/{node_id:path}",
    response_model=GraphData,
    responses={404: {"model": ErrorResponse}},
    tags=["graph"],
)
def node_neighborhood(session_id: str, node_id: str, radius: int = Query(default=1, ge=1, le=3)) -> GraphData:
    """The immediate neighborhood of a single node — used when the user clicks a node in the UI."""
    try:
        session = store.get(session_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc
    if session.graph is None:
        raise HTTPException(404, "No graph built yet for this session.")
    if not session.graph.has_node(node_id):
        raise HTTPException(404, f"Unknown node: {node_id}")

    import networkx as nx
    undirected = session.graph.to_undirected(as_view=True)
    sub_nodes = list(nx.ego_graph(undirected, node_id, radius=radius).nodes())
    payload = graph_viz.graph_to_json(session.graph, subset_nodes=sub_nodes)
    return GraphData(**payload)


# ---------------------------------------------------------------------------
# 4. Interactive standalone HTML view (optional; the React app has its own)
# ---------------------------------------------------------------------------
@app.get(
    "/api/graph/view/{session_id}",
    response_class=HTMLResponse,
    responses={404: {"model": ErrorResponse}},
    tags=["graph"],
)
def view_graph(session_id: str) -> HTMLResponse:
    try:
        session = store.get(session_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc
    if session.graph is None:
        raise HTTPException(404, "No graph built yet for this session. POST /api/graph/build first.")

    cached = settings.HTML_DIR / f"{session_id}.html"
    if cached.exists():
        return HTMLResponse(cached.read_text(encoding="utf-8"))

    html = graph_viz.render_graph_html(session.graph, title=f"Knowledge Graph — {session.filename}")
    return HTMLResponse(html)


# ---------------------------------------------------------------------------
# 5. Graph-grounded Q&A (chat)
# ---------------------------------------------------------------------------
@app.post(
    "/api/graph/ask",
    response_model=AskResponse,
    responses={404: {"model": ErrorResponse}, 400: {"model": ErrorResponse}},
    tags=["graph"],
)
def ask(req: AskRequest) -> AskResponse:
    try:
        session = store.get(req.session_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc
    if session.graph is None:
        raise HTTPException(404, "No graph built yet for this session. POST /api/graph/build first.")

    try:
        answer, matched, facts, match_scores = llm_qa.ask_graph(
            session.graph,
            req.question,
            session_id=req.session_id,
            radius=req.radius,
            max_facts=req.max_facts,
            model=req.model,
            top_k=req.top_k,
            min_similarity=req.min_similarity,
        )
    except Exception as exc:
        logger.exception("Q&A failed")
        raise HTTPException(400, f"Failed to answer question: {exc}") from exc

    subgraph_view_url = None
    graph_payload = None
    if matched:
        sub = llm_qa.get_context_subgraph(session.graph, matched, radius=req.radius)
        html = graph_viz.render_graph_html(
            session.graph, title=f"Answer subgraph — {req.question}", subset_nodes=list(sub.nodes())
        )
        fname = f"{req.session_id}_answer.html"
        (settings.HTML_DIR / fname).write_text(html, encoding="utf-8")
        subgraph_view_url = f"/api/graph/view-static/{fname}"
        graph_payload = GraphData(**graph_viz.graph_to_json(session.graph, subset_nodes=list(sub.nodes())))

    return AskResponse(
        question=req.question,
        answer=answer,
        matched_nodes=matched,
        match_scores=match_scores,
        facts=facts,
        subgraph_view_url=subgraph_view_url,
        graph=graph_payload,
    )


@app.get("/api/graph/view-static/{fname}", response_class=HTMLResponse, tags=["graph"])
def view_static(fname: str) -> HTMLResponse:
    path = settings.HTML_DIR / fname
    if not path.exists() or "/" in fname or ".." in fname:
        raise HTTPException(404, "Not found.")
    return HTMLResponse(path.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# 6. Session management
# ---------------------------------------------------------------------------
@app.get("/api/sessions", response_model=list[SessionInfo], tags=["sessions"])
def list_sessions() -> list[SessionInfo]:
    return [
        SessionInfo(
            session_id=s.session_id,
            filename=s.filename,
            created_at=s.created_at.isoformat(),
            has_graph=s.graph is not None,
            n_rows=len(s.df),
        )
        for s in store.list_sessions()
    ]


@app.delete("/api/sessions/{session_id}", tags=["sessions"])
def delete_session(session_id: str) -> dict:
    store.delete(session_id)
    embeddings.invalidate(session_id)
    return {"deleted": session_id}
