"""Pydantic schemas for requests/responses."""
from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field


class ColumnProfile(BaseModel):
    name: str
    dtype: str
    n_unique: int
    n_missing: int
    sample_values: list[Any]
    suggested_role: Literal[
        "id", "hierarchy", "attribute", "text", "ignore"
    ]


class UploadResponse(BaseModel):
    session_id: str
    filename: str
    n_rows: int
    n_columns: int
    columns: list[ColumnProfile]
    preview: list[dict[str, Any]]
    message: str = (
        "File loaded. Review `columns[].suggested_role`, then POST the "
        "mapping you want to /api/graph/build."
    )


class GraphBuildRequest(BaseModel):
    session_id: str

    # Dynamic column mapping — every field is optional so the endpoint
    # works on literally any spreadsheet shape.
    id_column: Optional[str] = Field(
        default=None,
        description="Column holding a unique row/ticket id. Auto-generated if omitted.",
    )
    hierarchy_columns: list[str] = Field(
        default_factory=list,
        description=(
            "Ordered categorical columns that form a parent->child chain, "
            "e.g. ['Category','Topic','Subtopic']. Leave empty to skip."
        ),
    )
    attribute_columns: list[str] = Field(
        default_factory=list,
        description=(
            "Other categorical columns to attach directly to each row-node, "
            "e.g. ['Intent','Sentiment']."
        ),
    )
    text_columns: list[str] = Field(
        default_factory=list,
        description="Free-text columns to run NLP extraction over (e.g. feedback/comments).",
    )
    extractor: Literal["spacy", "keybert", "both", "none"] = "spacy"
    canonicalize: bool = Field(
        default=False,
        description="Cluster near-duplicate extracted phrases into a single canonical label "
        "(requires sentence-transformers + scikit-learn).",
    )
    extract_people: bool = True

    node_label_column: Optional[str] = Field(
        default=None,
        description="Column to use as the human-readable label for each row-node "
        "(defaults to id_column, or the row index).",
    )


class GraphBuildResponse(BaseModel):
    session_id: str
    n_nodes: int
    n_edges: int
    node_types: dict[str, int]
    view_url: str
    message: str


class AskRequest(BaseModel):
    session_id: str
    question: str
    radius: int = 2
    max_facts: int = 80
    model: Optional[str] = None
    # Optional overrides for the semantic (embedding) node retrieval step.
    # Leave unset to use MATCH_TOP_K / MATCH_MIN_SIMILARITY from config.
    top_k: Optional[int] = Field(
        default=None, description="Max nodes to retrieve by embedding similarity."
    )
    min_similarity: Optional[float] = Field(
        default=None, description="Cosine similarity floor (0-1) for a node to count as matched."
    )


class AskResponse(BaseModel):
    question: str
    answer: str
    matched_nodes: list[str]
    match_scores: dict[str, float] = Field(
        default_factory=dict,
        description="Cosine similarity per matched node (semantic search). "
        "Empty if the keyword fallback matcher was used instead.",
    )
    facts: list[str]
    subgraph_view_url: Optional[str] = None
    graph: Optional["GraphData"] = None


class SessionInfo(BaseModel):
    session_id: str
    filename: str
    created_at: str
    has_graph: bool
    n_rows: int


class ErrorResponse(BaseModel):
    detail: str


# ---------------------------------------------------------------------------
# Admin settings (LLM provider + data source configuration)
# ---------------------------------------------------------------------------
class AdminSettingsUpdate(BaseModel):
    """Partial update; only include the sections/fields you want to change."""
    llm: Optional[dict[str, Any]] = None
    data_source: Optional[dict[str, Any]] = None
    extractor_default: Optional[str] = None
    canonicalize_default: Optional[bool] = None


class LLMTestRequest(BaseModel):
    provider: Optional[str] = None  # defaults to the currently configured provider
    prompt: str = "Reply with the single word: OK"


class LLMTestResponse(BaseModel):
    provider: str
    ok: bool
    reply: Optional[str] = None
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# BigQuery data source
# ---------------------------------------------------------------------------
class BigQueryTestRequest(BaseModel):
    project_id: Optional[str] = None
    credentials_json: Optional[str] = None


class BigQueryConnectRequest(BaseModel):
    project_id: Optional[str] = None
    credentials_json: Optional[str] = None
    dataset: Optional[str] = None
    table: Optional[str] = None
    query: Optional[str] = None
    row_limit: int = 200_000


# ---------------------------------------------------------------------------
# JSON graph payloads (for the React graph explorer / chat panel)
# ---------------------------------------------------------------------------
class GraphNode(BaseModel):
    id: str
    label: str
    type: str
    color: str
    degree: int = 0


class GraphEdge(BaseModel):
    id: str
    source: str
    target: str
    label: str


class GraphData(BaseModel):
    nodes: list[GraphNode]
    edges: list[GraphEdge]
    node_types: list[str]
    color_map: dict[str, str]
    n_nodes_total: int
    n_edges_total: int


# Resolve the forward reference to GraphData (defined after AskResponse above).
AskResponse.model_rebuild()
