"""
Semantic node search for GraphRAG retrieval.

Replaces the old plain-substring `find_matching_nodes` in llm_qa.py with
embedding-based "intelligent search": every node's `"<type>: <label>"`
text is embedded once (and cached per session), the incoming question is
embedded the same way, and the closest nodes by cosine similarity are
returned — so a question can match a node even if it doesn't share exact
words with it (e.g. "comp issues" -> "Compensation").

Uses `sentence-transformers` with `EMBEDDING_MODEL` (default
`all-MiniLM-L6-v2`), the same model already used for issue-phrase
canonicalization, so no extra model download is required if
`canonicalize=True` was ever used. Everything here is imported/loaded
lazily and guarded so the rest of the API keeps working — falling back to
keyword matching in llm_qa.py — on a machine without
`sentence-transformers` installed or reachable.
"""
from __future__ import annotations

import functools
import logging
import threading

import numpy as np

from ..config import settings

logger = logging.getLogger(__name__)

_INDEX_LOCK = threading.Lock()
# session_id -> (cache_key, node_ids, embedding_matrix)
_INDEX_CACHE: dict[str, tuple[str, list[str], np.ndarray]] = {}


@functools.lru_cache(maxsize=1)
def _get_embedder():
    from sentence_transformers import SentenceTransformer

    return SentenceTransformer(settings.EMBEDDING_MODEL)


def embeddings_available() -> bool:
    try:
        _get_embedder()
        return True
    except Exception as exc:
        logger.warning(
            "Embedding model %r unavailable (%s); semantic graph search will "
            "fall back to keyword matching. Install sentence-transformers and "
            "run once with internet access to download the model to fix this.",
            settings.EMBEDDING_MODEL,
            exc,
        )
        return False


def encode(texts: list[str]) -> np.ndarray:
    """Encode a batch of strings into L2-normalized embedding vectors."""
    if not texts:
        return np.zeros((0, 384), dtype=np.float32)
    model = _get_embedder()
    vectors = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
    return np.asarray(vectors, dtype=np.float32)


def cosine_top_k(
    query_vec: np.ndarray, matrix: np.ndarray, top_k: int, min_similarity: float
) -> list[tuple[int, float]]:
    """
    Indices (into `matrix`) of the top_k rows most similar to `query_vec`,
    restricted to similarity >= min_similarity, sorted best-first. Both
    `query_vec` and `matrix` rows are assumed L2-normalized, so cosine
    similarity reduces to a dot product.
    """
    if matrix.size == 0:
        return []
    sims = matrix @ query_vec
    order = np.argsort(-sims)[: max(top_k, 0)]
    return [(int(i), float(sims[i])) for i in order if sims[i] >= min_similarity]


def _node_text(graph, node_id) -> str:
    data = graph.nodes[node_id]
    label = data.get("label", node_id)
    ntype = data.get("type", "Other")
    return f"{ntype}: {label}"


def build_node_index(session_id: str, graph) -> tuple[list[str], np.ndarray]:
    """
    Embedding index for every node in `graph`, cached per session_id.
    Cheap to call repeatedly: recomputes only the first time for a given
    session, or after the graph has actually changed (node/edge count is
    used as a lightweight change signal so a rebuilt graph doesn't silently
    reuse a stale index).
    """
    cache_key = f"{graph.number_of_nodes()}:{graph.number_of_edges()}"
    with _INDEX_LOCK:
        cached = _INDEX_CACHE.get(session_id)
        if cached and cached[0] == cache_key:
            return cached[1], cached[2]

    node_ids = list(graph.nodes())
    texts = [_node_text(graph, n) for n in node_ids]
    matrix = encode(texts)

    with _INDEX_LOCK:
        _INDEX_CACHE[session_id] = (cache_key, node_ids, matrix)
    return node_ids, matrix


def invalidate(session_id: str) -> None:
    """Drop a session's cached node index (call after rebuilding its graph)."""
    with _INDEX_LOCK:
        _INDEX_CACHE.pop(session_id, None)
