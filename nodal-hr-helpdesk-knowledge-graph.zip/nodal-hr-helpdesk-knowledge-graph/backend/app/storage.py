"""
In-process session store.

Each uploaded file becomes a "session": a dataframe + (once built) a graph.
State lives in memory for speed, and is mirrored to disk (pickle) under
STORAGE_DIR so a session survives a process restart and graphs/html can be
served as static files.

This is intentionally simple (no external DB) — swap `SessionStore` for a
Redis/Postgres-backed implementation if you need multi-worker deployment.
"""
from __future__ import annotations

import pickle
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional

import networkx as nx
import pandas as pd

from .config import settings


@dataclass
class Session:
    session_id: str
    filename: str
    df: pd.DataFrame
    created_at: datetime = field(default_factory=datetime.utcnow)
    graph: Optional[nx.MultiDiGraph] = None
    graph_meta: dict = field(default_factory=dict)  # last build config, etc.


class SessionStore:
    def __init__(self) -> None:
        self._sessions: dict[str, Session] = {}
        self._lock = threading.Lock()

    # -- lifecycle ------------------------------------------------------
    def create(self, filename: str, df: pd.DataFrame) -> Session:
        sid = uuid.uuid4().hex[:12]
        sess = Session(session_id=sid, filename=filename, df=df)
        with self._lock:
            self._sessions[sid] = sess
        self._persist_df(sess)
        return sess

    def get(self, session_id: str) -> Session:
        with self._lock:
            sess = self._sessions.get(session_id)
        if sess is None:
            sess = self._load_from_disk(session_id)
        if sess is None:
            raise KeyError(f"Unknown session_id: {session_id}")
        return sess

    def set_graph(self, session_id: str, graph: nx.MultiDiGraph, meta: dict) -> None:
        sess = self.get(session_id)
        sess.graph = graph
        sess.graph_meta = meta
        with self._lock:
            self._sessions[session_id] = sess
        self._persist_graph(sess)

    def list_sessions(self) -> list[Session]:
        # Pick up any sessions persisted by a previous process that
        # haven't been touched (and thus lazily loaded) yet this run.
        on_disk_ids = {p.stem for p in settings.UPLOAD_DIR.glob("*.pkl")}
        with self._lock:
            known_ids = set(self._sessions.keys())
        for sid in on_disk_ids - known_ids:
            try:
                self._load_from_disk(sid)
            except Exception:
                continue  # skip corrupt/partial files rather than fail the whole listing

        with self._lock:
            sessions = list(self._sessions.values())
        self._expire_old(sessions)
        return sessions

    def delete(self, session_id: str) -> None:
        with self._lock:
            self._sessions.pop(session_id, None)
        for p in (self._df_path(session_id), self._graph_path(session_id)):
            if p.exists():
                p.unlink()

    # -- persistence helpers ---------------------------------------------
    def _df_path(self, sid: str):
        return settings.UPLOAD_DIR / f"{sid}.pkl"

    def _graph_path(self, sid: str):
        return settings.GRAPH_DIR / f"{sid}.gpickle"

    def _persist_df(self, sess: Session) -> None:
        with open(self._df_path(sess.session_id), "wb") as f:
            pickle.dump({"filename": sess.filename, "df": sess.df,
                         "created_at": sess.created_at}, f)

    def _persist_graph(self, sess: Session) -> None:
        with open(self._graph_path(sess.session_id), "wb") as f:
            pickle.dump({"graph": sess.graph, "meta": sess.graph_meta}, f)

    def _load_from_disk(self, sid: str) -> Optional[Session]:
        dpath = self._df_path(sid)
        if not dpath.exists():
            return None
        with open(dpath, "rb") as f:
            payload = pickle.load(f)
        sess = Session(
            session_id=sid,
            filename=payload["filename"],
            df=payload["df"],
            created_at=payload["created_at"],
        )
        gpath = self._graph_path(sid)
        if gpath.exists():
            with open(gpath, "rb") as f:
                gpayload = pickle.load(f)
            sess.graph = gpayload["graph"]
            sess.graph_meta = gpayload["meta"]
        with self._lock:
            self._sessions[sid] = sess
        return sess

    def _expire_old(self, sessions: list[Session]) -> None:
        if settings.SESSION_TTL_MINUTES <= 0:
            return
        cutoff = datetime.utcnow() - timedelta(minutes=settings.SESSION_TTL_MINUTES)
        for sess in sessions:
            if sess.created_at < cutoff:
                self.delete(sess.session_id)


store = SessionStore()
