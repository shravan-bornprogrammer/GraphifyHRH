"""
Central configuration for the Helpdesk Knowledge Graph API.

Everything is overridable via environment variables (or a `.env` file) as
*defaults*. On top of that, an admin-configurable layer
(`app/services/settings_store.py`) lets the running service be
reconfigured at runtime (data source, LLM provider/model, BigQuery
target, ...) from the Admin Settings screen in the frontend, without a
restart. Env vars are the fallback/seed values; the settings store is the
source of truth once the admin has saved something.
"""
from __future__ import annotations

import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # python-dotenv is optional; env vars can still be set by the shell.
    pass


class Settings:
    # --- Storage -----------------------------------------------------
    BASE_DIR: Path = Path(__file__).resolve().parent.parent
    STORAGE_DIR: Path = Path(os.getenv("STORAGE_DIR", BASE_DIR / "storage"))
    UPLOAD_DIR: Path = STORAGE_DIR / "uploads"
    GRAPH_DIR: Path = STORAGE_DIR / "graphs"
    HTML_DIR: Path = STORAGE_DIR / "html"
    CONFIG_DIR: Path = STORAGE_DIR / "config"

    # Max upload size (bytes). Default 25 MB.
    MAX_UPLOAD_BYTES: int = int(os.getenv("MAX_UPLOAD_BYTES", 25 * 1024 * 1024))

    # How long an in-memory/on-disk session is kept before it's eligible
    # for cleanup (minutes). 0 = never expire automatically.
    SESSION_TTL_MINUTES: int = int(os.getenv("SESSION_TTL_MINUTES", 240))

    # --- NLP / extraction ---------------------------------------------
    SPACY_MODEL: str = os.getenv("SPACY_MODEL", "en_core_web_sm")
    EMBEDDING_MODEL: str = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
    CANONICALIZE_DISTANCE_THRESHOLD: float = float(
        os.getenv("CANONICALIZE_DISTANCE_THRESHOLD", 0.35)
    )

    # --- Semantic node matching for /api/graph/ask (GraphRAG retrieval) ---
    # Replaces plain substring matching: the question and every node's
    # "type: label" text are embedded with EMBEDDING_MODEL (all-MiniLM-L6-v2
    # by default) and matched by cosine similarity. Falls back to keyword
    # substring matching automatically if sentence-transformers isn't
    # installed/loadable.
    MATCH_TOP_K: int = int(os.getenv("MATCH_TOP_K", 8))
    MATCH_MIN_SIMILARITY: float = float(os.getenv("MATCH_MIN_SIMILARITY", 0.35))

    # --- LLM providers (defaults / seed values; can be overridden at
    # runtime per-provider via the Admin Settings API & settings_store) ---
    # One of: "ollama", "openai", "anthropic", "gemini", "local", "none"
    LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "ollama")

    OLLAMA_HOST: str = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    OLLAMA_MODEL: str = os.getenv("OLLAMA_MODEL", "mistral:7b")

    OPENAI_API_KEY: str | None = os.getenv("OPENAI_API_KEY")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    ANTHROPIC_API_KEY: str | None = os.getenv("ANTHROPIC_API_KEY")
    ANTHROPIC_MODEL: str = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")

    GEMINI_API_KEY: str | None = os.getenv("GEMINI_API_KEY")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")

    # "local" = any OpenAI-chat-compatible local server (LM Studio,
    # text-generation-webui, vLLM's OpenAI shim, llama.cpp server, ...)
    LOCAL_LLM_BASE_URL: str = os.getenv("LOCAL_LLM_BASE_URL", "http://localhost:1234/v1")
    LOCAL_LLM_MODEL: str = os.getenv("LOCAL_LLM_MODEL", "local-model")
    LOCAL_LLM_API_KEY: str | None = os.getenv("LOCAL_LLM_API_KEY", "not-needed")

    # --- BigQuery (optional data source) -------------------------------
    BIGQUERY_PROJECT_ID: str | None = os.getenv("BIGQUERY_PROJECT_ID")
    BIGQUERY_CREDENTIALS_JSON_PATH: str | None = os.getenv("BIGQUERY_CREDENTIALS_JSON_PATH")

    # --- CORS -----------------------------------------------------------
    CORS_ORIGINS: list[str] = os.getenv("CORS_ORIGINS", "*").split(",")

    def ensure_dirs(self) -> None:
        for d in (self.UPLOAD_DIR, self.GRAPH_DIR, self.HTML_DIR, self.CONFIG_DIR):
            d.mkdir(parents=True, exist_ok=True)


settings = Settings()
settings.ensure_dirs()
