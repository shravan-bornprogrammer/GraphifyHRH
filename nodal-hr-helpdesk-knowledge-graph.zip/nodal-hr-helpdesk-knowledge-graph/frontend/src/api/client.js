import axios from "axios";

// In dev, Vite proxies /api -> the FastAPI server (see vite.config.js).
// In production, set VITE_API_BASE_URL to the deployed API origin.
const baseURL = import.meta.env.VITE_API_BASE_URL || "";

export const api = axios.create({ baseURL, timeout: 60_000 });

function unwrap(promise) {
  return promise.then((r) => r.data).catch((err) => {
    const detail =
      err?.response?.data?.detail ||
      err?.response?.data?.message ||
      err?.message ||
      "Request failed";
    throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
  });
}

// ---- Admin settings -------------------------------------------------
export const getAdminSettings = () => unwrap(api.get("/api/admin/settings"));
export const updateAdminSettings = (patch) => unwrap(api.post("/api/admin/settings", patch));
export const listLLMProviders = () => unwrap(api.get("/api/admin/llm-providers"));
export const testLLM = (payload) => unwrap(api.post("/api/admin/llm/test", payload));

// ---- Data sources -----------------------------------------------------
export const uploadFile = (file, sheetName, onProgress) => {
  const form = new FormData();
  form.append("file", file);
  const params = sheetName ? { sheet_name: sheetName } : {};
  return unwrap(
    api.post("/api/upload", form, {
      params,
      headers: { "Content-Type": "multipart/form-data" },
      onUploadProgress: onProgress,
    })
  );
};

export const testBigQuery = (payload) => unwrap(api.post("/api/connect/bigquery/test", payload));
export const listBigQueryTables = (dataset) =>
  unwrap(api.get("/api/connect/bigquery/tables", { params: { dataset } }));
export const connectBigQuery = (payload) => unwrap(api.post("/api/connect/bigquery", payload));

// ---- Graph build / data ----------------------------------------------
export const buildGraph = (payload) => unwrap(api.post("/api/graph/build", payload));
export const getGraphData = (sessionId, params = {}) =>
  unwrap(api.get(`/api/graph/data/${sessionId}`, { params }));
export const getNodeNeighborhood = (sessionId, nodeId, radius = 1) =>
  unwrap(api.get(`/api/graph/node/${sessionId}/${encodeURIComponent(nodeId)}`, { params: { radius } }));

// ---- Chat / Q&A ---------------------------------------------------------
export const askGraph = (payload) => unwrap(api.post("/api/graph/ask", payload));

// ---- Sessions -----------------------------------------------------------
export const listSessions = () => unwrap(api.get("/api/sessions"));
export const deleteSession = (sessionId) => unwrap(api.delete(`/api/sessions/${sessionId}`));
