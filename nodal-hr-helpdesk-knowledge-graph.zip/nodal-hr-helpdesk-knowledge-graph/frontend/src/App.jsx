import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { SessionProvider } from "./context/SessionContext.jsx";
import AppShell from "./components/AppShell.jsx";
import SetupPage from "./pages/SetupPage.jsx";
import GraphExplorerPage from "./pages/GraphExplorerPage.jsx";
import ChatPage from "./pages/ChatPage.jsx";

export default function App() {
  return (
    <SessionProvider>
      <BrowserRouter>
        <AppShell>
          <Routes>
            <Route path="/" element={<SetupPage />} />
            <Route path="/explore" element={<GraphExplorerPage />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AppShell>
      </BrowserRouter>
    </SessionProvider>
  );
}
