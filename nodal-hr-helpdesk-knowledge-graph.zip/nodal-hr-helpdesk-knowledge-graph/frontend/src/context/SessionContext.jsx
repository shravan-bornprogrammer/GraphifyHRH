import { createContext, useCallback, useContext, useMemo, useState } from "react";

const SessionContext = createContext(null);

const STORAGE_KEY = "nodal.session.v1";

function loadPersisted() {
  try {
    const raw = window.sessionStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function persist(state) {
  try {
    window.sessionStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* ignore */
  }
}

export function SessionProvider({ children }) {
  const persisted = loadPersisted();

  const [sessionId, setSessionId] = useState(persisted?.sessionId || null);
  const [filename, setFilename] = useState(persisted?.filename || null);
  const [sourceType, setSourceType] = useState(persisted?.sourceType || null); // "upload" | "bigquery"
  const [columns, setColumns] = useState(persisted?.columns || []);
  const [preview, setPreview] = useState(persisted?.preview || []);
  const [buildConfig, setBuildConfig] = useState(persisted?.buildConfig || null);
  const [graphSummary, setGraphSummary] = useState(persisted?.graphSummary || null);

  const setDataset = useCallback((payload, sourceType) => {
    setSessionId(payload.session_id);
    setFilename(payload.filename);
    setSourceType(sourceType);
    setColumns(payload.columns || []);
    setPreview(payload.preview || []);
    setGraphSummary(null);
    setBuildConfig(null);
    persist({
      sessionId: payload.session_id,
      filename: payload.filename,
      sourceType,
      columns: payload.columns || [],
      preview: payload.preview || [],
      buildConfig: null,
      graphSummary: null,
    });
  }, []);

  const setGraphBuilt = useCallback(
    (summary, config) => {
      setGraphSummary(summary);
      setBuildConfig(config);
      persist({
        sessionId,
        filename,
        sourceType,
        columns,
        preview,
        buildConfig: config,
        graphSummary: summary,
      });
    },
    [sessionId, filename, sourceType, columns, preview]
  );

  const reset = useCallback(() => {
    setSessionId(null);
    setFilename(null);
    setSourceType(null);
    setColumns([]);
    setPreview([]);
    setBuildConfig(null);
    setGraphSummary(null);
    window.sessionStorage.removeItem(STORAGE_KEY);
  }, []);

  const value = useMemo(
    () => ({
      sessionId,
      filename,
      sourceType,
      columns,
      preview,
      buildConfig,
      graphSummary,
      hasData: Boolean(sessionId),
      hasGraph: Boolean(graphSummary),
      setDataset,
      setGraphBuilt,
      reset,
    }),
    [sessionId, filename, sourceType, columns, preview, buildConfig, graphSummary, setDataset, setGraphBuilt, reset]
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession() {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error("useSession must be used within a SessionProvider");
  return ctx;
}
