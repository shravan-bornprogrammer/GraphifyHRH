import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Loader2, Send, Sparkles } from "lucide-react";
import { askGraph } from "../api/client.js";
import { useSession } from "../context/SessionContext.jsx";
import GraphCanvas from "../components/GraphCanvas.jsx";
import GraphLegend from "../components/GraphLegend.jsx";
import "./ChatPage.css";

const SUGGESTIONS = [
  "What are the most common categories of complaints?",
  "Tell me about issues related to payroll",
  "What sentiment is associated with leave requests?",
  "Which people are mentioned most often?",
];

export default function ChatPage() {
  const { sessionId, hasGraph, filename } = useSession();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [activeGraph, setActiveGraph] = useState(null);
  const [activeMatched, setActiveMatched] = useState(new Set());
  const listRef = useRef(null);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, sending]);

  const send = async (text) => {
    const question = (text ?? input).trim();
    if (!question || sending) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: question }]);
    setSending(true);
    try {
      const res = await askGraph({ session_id: sessionId, question, radius: 2, max_facts: 60 });
      setMessages((m) => [
        ...m,
        {
          role: "assistant",
          text: res.answer,
          matched: res.matched_nodes,
          facts: res.facts,
          graph: res.graph,
        },
      ]);
      if (res.graph) {
        setActiveGraph(res.graph);
        setActiveMatched(new Set(res.matched_nodes));
      }
    } catch (err) {
      setMessages((m) => [...m, { role: "assistant", text: "Error: " + err.message, isError: true }]);
    } finally {
      setSending(false);
    }
  };

  const showAnswerGraph = (msg) => {
    if (!msg.graph) return;
    setActiveGraph(msg.graph);
    setActiveMatched(new Set(msg.matched));
  };

  if (!hasGraph) {
    return (
      <div className="explorer-empty">
        <h2>No graph to chat with yet</h2>
        <p>Build a knowledge graph first — head back to Data Source.</p>
        <Link className="btn btn-primary" to="/">
          Go to Data Source
        </Link>
      </div>
    );
  }

  return (
    <div className="chat-page">
      <section className="chat-panel">
        <header className="chat-header">
          <div>
            <div className="page-eyebrow">Step 03</div>
            <h2>Ask the graph</h2>
          </div>
          <span className="pill pill-ok">{filename}</span>
        </header>

        <div className="chat-scroll" ref={listRef}>
          {messages.length === 0 && (
            <div className="chat-empty">
              <Sparkles size={20} />
              <p>Ask a question about your helpdesk data — answers are grounded in the graph, with the exact facts used shown below.</p>
              <div className="chat-suggestions">
                {SUGGESTIONS.map((s) => (
                  <button key={s} className="btn btn-subtle btn-sm" onClick={() => send(s)}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m, i) => (
            <div key={i} className={"bubble-row " + m.role}>
              <div className={"bubble " + m.role + (m.isError ? " error" : "")}>
                <p>{m.text}</p>
                {m.role === "assistant" && m.facts?.length > 0 && (
                  <div className="bubble-facts">
                    <button className="bubble-facts-toggle" onClick={() => showAnswerGraph(m)}>
                      Show {m.matched.length} matched node(s) · {m.facts.length} fact(s) in graph →
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {sending && (
            <div className="bubble-row assistant">
              <div className="bubble assistant">
                <Loader2 size={15} className="spin" /> Thinking…
              </div>
            </div>
          )}
        </div>

        <form
          className="chat-input-bar"
          onSubmit={(e) => {
            e.preventDefault();
            send();
          }}
        >
          <input
            type="text"
            placeholder="Ask about categories, sentiment, people, root causes…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <button className="btn btn-primary" type="submit" disabled={sending || !input.trim()}>
            <Send size={15} />
          </button>
        </form>
      </section>

      <section className="chat-graph-panel">
        <div className="chat-graph-head">
          <div className="admin-card-eyebrow">Context graph</div>
          <p className="field-hint">
            {activeGraph
              ? "Nodes highlighted below are exactly what grounded the answer."
              : "Ask a question to see the exact nodes & edges used to answer it."}
          </p>
        </div>
        {activeGraph && <GraphLegend colorMap={activeGraph.color_map} />}
        <div className="chat-graph-canvas">
          {activeGraph ? (
            <GraphCanvas data={activeGraph} highlightIds={activeMatched} />
          ) : (
            <div className="explorer-nomatch">No context yet</div>
          )}
        </div>
      </section>
    </div>
  );
}
