import { useCallback, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Database, FileSpreadsheet, Loader2, UploadCloud, Wand2 } from "lucide-react";
import { buildGraph, connectBigQuery, testBigQuery, uploadFile } from "../api/client.js";
import { useSession } from "../context/SessionContext.jsx";
import AdminSettingsPanel from "../components/AdminSettingsPanel.jsx";
import ColumnMapper from "../components/ColumnMapper.jsx";
import "./SetupPage.css";

const EXTRACTORS = [
  { id: "spacy", label: "spaCy — concepts, entities & people" },
  { id: "keybert", label: "KeyBERT — short issue phrases" },
  { id: "both", label: "Both" },
  { id: "none", label: "None — structured columns only" },
];

export default function SetupPage() {
  const navigate = useNavigate();
  const { sessionId, filename, columns, preview, setDataset, setGraphBuilt, hasData } = useSession();

  const [tab, setTab] = useState("upload"); // upload | bigquery
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const fileInputRef = useRef(null);

  // BigQuery form state
  const [bq, setBq] = useState({ project_id: "", credentials_json: "", dataset: "", table: "", query: "" });
  const [bqTesting, setBqTesting] = useState(false);
  const [bqTestResult, setBqTestResult] = useState(null);
  const [bqConnecting, setBqConnecting] = useState(false);

  // Column mapping state
  const [roles, setRoles] = useState({});
  const [idColumnOverride, setIdColumnOverride] = useState(null);
  const [extractor, setExtractor] = useState("spacy");
  const [canonicalize, setCanonicalize] = useState(false);
  const [extractPeople, setExtractPeople] = useState(true);
  const [building, setBuilding] = useState(false);
  const [buildError, setBuildError] = useState(null);

  const effectiveRoles = useMemo(() => {
    const out = {};
    for (const c of columns) out[c.name] = roles[c.name] || c.suggested_role;
    return out;
  }, [columns, roles]);

  const hierarchyOrder = useMemo(
    () => columns.filter((c) => effectiveRoles[c.name] === "hierarchy").map((c) => c.name),
    [columns, effectiveRoles]
  );
  const [hierarchyOverride, setHierarchyOverride] = useState(null);
  const finalHierarchyOrder = hierarchyOverride && hierarchyOverride.length === hierarchyOrder.length
    ? hierarchyOverride
    : hierarchyOrder;

  const idColumn =
    idColumnOverride !== null
      ? idColumnOverride
      : columns.find((c) => effectiveRoles[c.name] === "id")?.name || null;

  const attributeColumns = columns.filter((c) => effectiveRoles[c.name] === "attribute").map((c) => c.name);
  const textColumns = columns.filter((c) => effectiveRoles[c.name] === "text").map((c) => c.name);

  const handleFiles = useCallback(
    async (files) => {
      const file = files?.[0];
      if (!file) return;
      setUploadError(null);
      setUploading(true);
      try {
        const res = await uploadFile(file);
        setDataset(res, "upload");
        setRoles({});
        setHierarchyOverride(null);
        setIdColumnOverride(null);
      } catch (err) {
        setUploadError(err.message);
      } finally {
        setUploading(false);
      }
    },
    [setDataset]
  );

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    handleFiles(e.dataTransfer.files);
  };

  const testBq = async () => {
    setBqTesting(true);
    setBqTestResult(null);
    try {
      const res = await testBigQuery({ project_id: bq.project_id || undefined, credentials_json: bq.credentials_json || undefined });
      setBqTestResult({ ok: true, ...res });
    } catch (err) {
      setBqTestResult({ ok: false, error: err.message });
    } finally {
      setBqTesting(false);
    }
  };

  const connectBq = async () => {
    setBqConnecting(true);
    setUploadError(null);
    try {
      const res = await connectBigQuery({
        project_id: bq.project_id || undefined,
        credentials_json: bq.credentials_json || undefined,
        dataset: bq.query ? undefined : bq.dataset || undefined,
        table: bq.query ? undefined : bq.table || undefined,
        query: bq.query || undefined,
      });
      setDataset(res, "bigquery");
      setRoles({});
      setHierarchyOverride(null);
      setIdColumnOverride(null);
    } catch (err) {
      setUploadError(err.message);
    } finally {
      setBqConnecting(false);
    }
  };

  const runBuild = async () => {
    setBuilding(true);
    setBuildError(null);
    try {
      const payload = {
        session_id: sessionId,
        id_column: idColumn,
        hierarchy_columns: finalHierarchyOrder,
        attribute_columns: attributeColumns,
        text_columns: textColumns,
        extractor,
        canonicalize,
        extract_people: extractPeople,
        node_label_column: idColumnOverride || undefined,
      };
      const res = await buildGraph(payload);
      setGraphBuilt(res, payload);
      navigate("/explore");
    } catch (err) {
      setBuildError(err.message);
    } finally {
      setBuilding(false);
    }
  };

  return (
    <div className="setup-page">
      <header className="page-header">
        <div>
          <div className="page-eyebrow">Step 01</div>
          <h1>Bring in your helpdesk data</h1>
          <p className="page-sub">
            Upload a spreadsheet or connect directly to BigQuery, map columns to graph roles, then build
            a searchable knowledge graph.
          </p>
        </div>
        <AdminSettingsPanel />
      </header>

      <div className="setup-grid">
        <section className="card setup-source-card">
          <div className="tabbar">
            <button className={"tab" + (tab === "upload" ? " active" : "")} onClick={() => setTab("upload")}>
              <FileSpreadsheet size={15} /> Excel / CSV
            </button>
            <button className={"tab" + (tab === "bigquery" ? " active" : "")} onClick={() => setTab("bigquery")}>
              <Database size={15} /> BigQuery
            </button>
          </div>

          {tab === "upload" && (
            <div
              className={"dropzone" + (dragOver ? " over" : "")}
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={onDrop}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls,.xlsm,.csv,.tsv"
                hidden
                onChange={(e) => handleFiles(e.target.files)}
              />
              {uploading ? (
                <>
                  <Loader2 size={26} className="spin" />
                  <p>Parsing spreadsheet…</p>
                </>
              ) : (
                <>
                  <UploadCloud size={26} />
                  <p>
                    <strong>Drop a file here</strong> or click to browse
                  </p>
                  <span className="dropzone-hint">.xlsx, .xls, .csv, .tsv — up to 25 MB</span>
                </>
              )}
            </div>
          )}

          {tab === "bigquery" && (
            <div className="bq-form">
              <div className="field">
                <label>GCP project ID</label>
                <input
                  type="text"
                  placeholder="my-gcp-project (optional if set in Admin settings)"
                  value={bq.project_id}
                  onChange={(e) => setBq((s) => ({ ...s, project_id: e.target.value }))}
                />
              </div>
              <div className="field">
                <label>Service-account credentials JSON (optional)</label>
                <textarea
                  rows={3}
                  placeholder='{"type":"service_account", ...} — leave blank to use Admin settings / ADC'
                  value={bq.credentials_json}
                  onChange={(e) => setBq((s) => ({ ...s, credentials_json: e.target.value }))}
                />
              </div>
              <div className="bq-row">
                <div className="field">
                  <label>Dataset</label>
                  <input
                    type="text"
                    placeholder="hr_helpdesk"
                    value={bq.dataset}
                    onChange={(e) => setBq((s) => ({ ...s, dataset: e.target.value }))}
                  />
                </div>
                <div className="field">
                  <label>Table</label>
                  <input
                    type="text"
                    placeholder="tickets"
                    value={bq.table}
                    onChange={(e) => setBq((s) => ({ ...s, table: e.target.value }))}
                  />
                </div>
              </div>
              <div className="field">
                <label>…or a custom SQL query (overrides dataset/table)</label>
                <textarea
                  rows={2}
                  placeholder="SELECT * FROM `project.dataset.tickets` WHERE status = 'closed'"
                  value={bq.query}
                  onChange={(e) => setBq((s) => ({ ...s, query: e.target.value }))}
                />
              </div>
              <div className="admin-actions">
                <button className="btn btn-subtle btn-sm" onClick={testBq} disabled={bqTesting}>
                  {bqTesting ? <Loader2 size={13} className="spin" /> : null}
                  Test connection
                </button>
                <button
                  className="btn btn-primary btn-sm"
                  onClick={connectBq}
                  disabled={bqConnecting || (!bq.query && (!bq.dataset || !bq.table))}
                >
                  {bqConnecting ? <Loader2 size={13} className="spin" /> : null}
                  Load data
                </button>
              </div>
              {bqTestResult && (
                <div className={"admin-test-result " + (bqTestResult.ok ? "ok" : "fail")}>
                  {bqTestResult.ok
                    ? `✓ Connected to ${bqTestResult.project_id} — ${bqTestResult.datasets?.length ?? 0} dataset(s) visible`
                    : "✕ " + bqTestResult.error}
                </div>
              )}
            </div>
          )}

          {uploadError && <div className="admin-test-result fail">{uploadError}</div>}
        </section>

        <section className="card setup-preview-card">
          <div className="admin-card-eyebrow">Dataset</div>
          {!hasData ? (
            <div className="detail-empty" style={{ padding: "28px 4px" }}>
              Load a file or a BigQuery table to see a preview here.
            </div>
          ) : (
            <>
              <h3 className="preview-filename">{filename}</h3>
              <div className="preview-scroll">
                <table className="preview-table">
                  <thead>
                    <tr>
                      {columns.map((c) => (
                        <th key={c.name}>{c.name}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {preview.map((row, i) => (
                      <tr key={i}>
                        {columns.map((c) => (
                          <td key={c.name}>{String(row[c.name] ?? "")}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </section>
      </div>

      {hasData && (
        <section className="card setup-mapping-card">
          <div className="admin-card-eyebrow">Column mapping</div>
          <h3>Tell Nodal what each column means</h3>
          <p className="field-hint" style={{ marginBottom: 18 }}>
            Roles are pre-suggested from the data shape. Adjust anything, then build the graph.
          </p>
          <ColumnMapper
            columns={columns}
            roles={roles}
            onRoleChange={(name, role) => setRoles((r) => ({ ...r, [name]: role }))}
            hierarchyOrder={finalHierarchyOrder}
            onReorder={(from, to) => {
              const next = [...finalHierarchyOrder];
              const [item] = next.splice(from, 1);
              next.splice(to, 0, item);
              setHierarchyOverride(next);
            }}
            idColumn={idColumnOverride}
            onIdColumnChange={setIdColumnOverride}
          />

          <hr className="admin-divider" />

          <div className="build-options">
            <div className="field">
              <label>Text extraction</label>
              <select value={extractor} onChange={(e) => setExtractor(e.target.value)}>
                {EXTRACTORS.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.label}
                  </option>
                ))}
              </select>
            </div>
            <label className="checkbox-field">
              <input type="checkbox" checked={extractPeople} onChange={(e) => setExtractPeople(e.target.checked)} />
              Extract people mentioned in free text
            </label>
            <label className="checkbox-field">
              <input type="checkbox" checked={canonicalize} onChange={(e) => setCanonicalize(e.target.checked)} />
              Canonicalize near-duplicate issue phrases
            </label>
          </div>

          {buildError && <div className="admin-test-result fail">{buildError}</div>}

          <div className="build-cta">
            <button className="btn btn-primary" onClick={runBuild} disabled={building || !sessionId}>
              {building ? <Loader2 size={15} className="spin" /> : <Wand2 size={15} />}
              Build knowledge graph
            </button>
            <span className="field-hint">
              {textColumns.length} text · {attributeColumns.length} attribute · {finalHierarchyOrder.length} hierarchy column(s)
            </span>
          </div>
        </section>
      )}
    </div>
  );
}
