import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Loader2, Search, ZoomIn } from "lucide-react";
import { getGraphData, getNodeNeighborhood } from "../api/client.js";
import { useSession } from "../context/SessionContext.jsx";
import GraphCanvas from "../components/GraphCanvas.jsx";
import GraphLegend from "../components/GraphLegend.jsx";
import NodeDetailPanel from "../components/NodeDetailPanel.jsx";
import "./GraphExplorerPage.css";

export default function GraphExplorerPage() {
  const { sessionId, hasGraph, filename } = useSession();
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [activeTypes, setActiveTypes] = useState(null); // null = all
  const [selectedNode, setSelectedNode] = useState(null);
  const [neighborhood, setNeighborhood] = useState(null);
  const [neighborhoodLoading, setNeighborhoodLoading] = useState(false);
  const fgRef = useRef(null);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query), 300);
    return () => clearTimeout(t);
  }, [query]);

  const load = useCallback(() => {
    if (!sessionId || !hasGraph) return;
    setLoading(true);
    setError(null);
    const params = {};
    if (debouncedQuery) params.q = debouncedQuery;
    if (activeTypes) params.node_type = Array.from(activeTypes).join(",");
    getGraphData(sessionId, params)
      .then(setData)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [sessionId, hasGraph, debouncedQuery, activeTypes]);

  useEffect(() => {
    load();
  }, [load]);

  const toggleType = (type) => {
    setActiveTypes((prev) => {
      const allTypes = new Set(data?.node_types || []);
      const current = prev ? new Set(prev) : new Set(allTypes);
      if (current.has(type)) {
        current.delete(type);
      } else {
        current.add(type);
      }
      // If everything is selected again, go back to "no filter" (null)
      if (current.size === allTypes.size) return null;
      return current;
    });
  };

  const highlightIds = useMemo(() => {
    if (!debouncedQuery || !data) return new Set();
    const ql = debouncedQuery.toLowerCase();
    return new Set(data.nodes.filter((n) => n.label.toLowerCase().includes(ql)).map((n) => n.id));
  }, [debouncedQuery, data]);

  const onNodeClick = async (node) => {
    setSelectedNode(node);
    setNeighborhoodLoading(true);
    fgRef.current?.centerAt?.(node.x, node.y, 500);
    fgRef.current?.zoom?.(3, 500);
    try {
      const nb = await getNodeNeighborhood(sessionId, node.id, 1);
      setNeighborhood(nb);
    } catch {
      setNeighborhood(null);
    } finally {
      setNeighborhoodLoading(false);
    }
  };

  const focusNode = (node) => {
    const full = data?.nodes.find((n) => n.id === node.id);
    if (full) onNodeClick(full);
  };

  if (!hasGraph) {
    return (
      <div className="explorer-empty">
        <h2>No graph built yet</h2>
        <p>Head back to Data Source to upload a file (or connect BigQuery) and build a graph first.</p>
        <Link className="btn btn-primary" to="/">
          Go to Data Source
        </Link>
      </div>
    );
  }

  return (
    <div className="explorer-page">
      <div className="explorer-toolbar">
        <div className="explorer-search">
          <Search size={15} />
          <input
            type="text"
            placeholder="Search nodes by label or type…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          {loading && <Loader2 size={14} className="spin" />}
        </div>
        <div className="explorer-meta">
          <span className="pill pill-ok">{filename}</span>
          <span className="explorer-count">
            {data ? `${data.n_nodes_total} nodes · ${data.n_edges_total} edges` : "…"}
          </span>
          <button className="icon-btn" title="Fit to view" onClick={() => fgRef.current?.zoomToFit?.(500, 60)}>
            <ZoomIn size={15} />
          </button>
        </div>
      </div>

      {data && (
        <GraphLegend colorMap={data.color_map} activeTypes={activeTypes} onToggle={toggleType} />
      )}

      {error && <div className="admin-test-result fail" style={{ margin: "0 20px" }}>{error}</div>}

      <div className="explorer-canvas-wrap">
        {data && data.nodes.length > 0 ? (
          <GraphCanvas
            ref={fgRef}
            data={data}
            highlightIds={highlightIds}
            onNodeClick={onNodeClick}
            selectedId={selectedNode?.id}
          />
        ) : (
          !loading && <div className="explorer-nomatch">No nodes match this search/filter.</div>
        )}

        {selectedNode && (
          <NodeDetailPanel
            node={selectedNode}
            neighborhood={neighborhood}
            loading={neighborhoodLoading}
            onClose={() => {
              setSelectedNode(null);
              setNeighborhood(null);
            }}
            onFocusNode={focusNode}
          />
        )}
      </div>
    </div>
  );
}
