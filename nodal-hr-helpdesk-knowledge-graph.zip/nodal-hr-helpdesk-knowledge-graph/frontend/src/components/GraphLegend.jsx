export default function GraphLegend({ colorMap, activeTypes, onToggle }) {
  const types = Object.keys(colorMap || {});
  if (!types.length) return null;

  return (
    <div className="legend">
      {types.map((t) => {
        const isActive = !activeTypes || activeTypes.has(t);
        return (
          <button
            key={t}
            className={"legend-chip" + (isActive ? "" : " off")}
            onClick={() => onToggle?.(t)}
            type="button"
          >
            <span className="dot" style={{ background: colorMap[t] }} />
            {t}
          </button>
        );
      })}
    </div>
  );
}
