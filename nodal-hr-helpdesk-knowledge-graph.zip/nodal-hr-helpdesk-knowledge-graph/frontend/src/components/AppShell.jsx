import { NavLink } from "react-router-dom";
import { useSession } from "../context/SessionContext.jsx";
import "./AppShell.css";

const NAV = [
  {
    to: "/",
    label: "Data Source",
    step: "01",
    hint: "Upload & configure",
  },
  {
    to: "/explore",
    label: "Graph Explorer",
    step: "02",
    hint: "Visualize & search",
  },
  {
    to: "/chat",
    label: "Ask the Graph",
    step: "03",
    hint: "Chat with citations",
  },
];

export default function AppShell({ children }) {
  const { hasData, hasGraph, filename, sourceType } = useSession();

  return (
    <div className="shell">
      <aside className="shell-rail">
        <div className="brand">
          <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
            <circle cx="6" cy="6" r="3" fill="#1f8a70" />
            <circle cx="20" cy="6" r="3" fill="#cf8a1e" />
            <circle cx="13" cy="20" r="3" fill="#131a2b" />
            <path d="M8.5 7.5L11 18M17.5 7.5L15 18M9 6H17" stroke="#c5cdc9" strokeWidth="1.4" />
          </svg>
          <div>
            <div className="brand-name">Nodal</div>
            <div className="brand-tag">HR Helpdesk Graph</div>
          </div>
        </div>

        <nav className="rail-nav">
          {NAV.map((item) => {
            const locked = (item.to === "/explore" && !hasGraph) || (item.to === "/chat" && !hasGraph);
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  "rail-link" + (isActive ? " active" : "") + (locked ? " locked" : "")
                }
                onClick={(e) => locked && e.preventDefault()}
              >
                <span className="rail-step">{item.step}</span>
                <span className="rail-text">
                  <span className="rail-label">{item.label}</span>
                  <span className="rail-hint">{item.hint}</span>
                </span>
              </NavLink>
            );
          })}
        </nav>

        <div className="rail-status">
          <div className="rail-status-title">Active dataset</div>
          {hasData ? (
            <>
              <div className="rail-status-file" title={filename}>
                {filename}
              </div>
              <div className="rail-status-row">
                <span className={"dot " + (sourceType === "bigquery" ? "dot-amber" : "dot-primary")} />
                {sourceType === "bigquery" ? "BigQuery" : "File upload"}
                {hasGraph ? " · graph built" : " · not built"}
              </div>
            </>
          ) : (
            <div className="rail-status-empty">No dataset loaded yet</div>
          )}
        </div>
      </aside>

      <main className="shell-main">{children}</main>
    </div>
  );
}
