import { X } from "lucide-react";

export default function NodeDetailPanel({ node, neighborhood, loading, onClose, onFocusNode }) {
  if (!node) return null;

  const facts = [];
  if (neighborhood) {
    const nodeById = Object.fromEntries(neighborhood.nodes.map((n) => [n.id, n]));
    for (const e of neighborhood.edges) {
      if (e.source === node.id || e.target === node.id) {
        const other = e.source === node.id ? nodeById[e.target] : nodeById[e.source];
        if (!other) continue;
        facts.push({
          direction: e.source === node.id ? "out" : "in",
          label: e.label,
          other,
        });
      }
    }
  }

  return (
    <aside className="detail-panel">
      <div className="detail-head">
        <div>
          <span className="pill pill-off" style={{ background: node.color + "22", color: node.color }}>
            {node.type}
          </span>
          <h3 className="detail-title">{node.label}</h3>
        </div>
        <button className="icon-btn" onClick={onClose} aria-label="Close">
          <X size={16} />
        </button>
      </div>

      <div className="detail-body">
        <div className="detail-section-label">Connected facts ({facts.length})</div>
        {loading && <div className="detail-empty">Loading neighborhood…</div>}
        {!loading && facts.length === 0 && (
          <div className="detail-empty">No connections found for this node.</div>
        )}
        <ul className="fact-list">
          {facts.map((f, i) => (
            <li key={i} className="fact-item" onClick={() => onFocusNode?.(f.other)}>
              <span className="fact-rel">{f.direction === "out" ? f.label : "← " + f.label}</span>
              <span className="fact-target">
                <span className="dot" style={{ background: f.other.color }} />
                {f.other.label}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}
