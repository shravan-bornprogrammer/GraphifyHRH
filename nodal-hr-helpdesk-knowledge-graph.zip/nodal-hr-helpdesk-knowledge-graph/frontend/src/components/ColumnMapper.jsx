import { ArrowDown, ArrowUp } from "lucide-react";

const ROLES = [
  { id: "id", label: "Row ID" },
  { id: "hierarchy", label: "Hierarchy" },
  { id: "attribute", label: "Attribute" },
  { id: "text", label: "Free text" },
  { id: "ignore", label: "Ignore" },
];

const ROLE_HINT = {
  id: "Unique row/ticket identifier — used as the node label.",
  hierarchy: "Forms a parent → child chain (e.g. Category → Topic → Subtopic). Order matters below.",
  attribute: "Attached directly to each row as a flat fact (status, sentiment, owner…).",
  text: "Free-text column run through NLP to extract keywords, issues, and people.",
  ignore: "Not used when building the graph.",
};

export default function ColumnMapper({ columns, roles, onRoleChange, hierarchyOrder, onReorder, idColumn, onIdColumnChange }) {
  return (
    <div className="mapper">
      <table className="mapper-table">
        <thead>
          <tr>
            <th>Column</th>
            <th>Sample values</th>
            <th>Unique</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          {columns.map((col) => {
            const role = roles[col.name] || col.suggested_role;
            return (
              <tr key={col.name}>
                <td>
                  <div className="mapper-colname">{col.name}</div>
                  <div className="mapper-dtype">{col.dtype}</div>
                </td>
                <td className="mapper-samples">
                  {col.sample_values.slice(0, 3).join(" · ") || <em>empty</em>}
                </td>
                <td className="mapper-unique">{col.n_unique}</td>
                <td>
                  <select value={role} onChange={(e) => onRoleChange(col.name, e.target.value)}>
                    {ROLES.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.label}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <div className="mapper-hint-row">
        {Object.entries(ROLE_HINT).map(([k, v]) => (
          <div key={k} className="mapper-hint">
            <strong>{ROLES.find((r) => r.id === k).label}:</strong> {v}
          </div>
        ))}
      </div>

      {hierarchyOrder.length > 1 && (
        <div className="hierarchy-order">
          <div className="mapper-section-label">Hierarchy order (parent → child)</div>
          <ol>
            {hierarchyOrder.map((name, idx) => (
              <li key={name}>
                <span className="hierarchy-chain-label">{name}</span>
                <span className="hierarchy-order-btns">
                  <button
                    type="button"
                    className="icon-btn"
                    disabled={idx === 0}
                    onClick={() => onReorder(idx, idx - 1)}
                  >
                    <ArrowUp size={13} />
                  </button>
                  <button
                    type="button"
                    className="icon-btn"
                    disabled={idx === hierarchyOrder.length - 1}
                    onClick={() => onReorder(idx, idx + 1)}
                  >
                    <ArrowDown size={13} />
                  </button>
                </span>
              </li>
            ))}
          </ol>
        </div>
      )}

      <div className="field" style={{ maxWidth: 320, marginTop: 18 }}>
        <label>Node label column (optional)</label>
        <select value={idColumn || ""} onChange={(e) => onIdColumnChange(e.target.value || null)}>
          <option value="">Auto (use Row ID column, or row index)</option>
          {columns.map((c) => (
            <option key={c.name} value={c.name}>
              {c.name}
            </option>
          ))}
        </select>
        <div className="field-hint">Which column's value labels each row-node in the graph.</div>
      </div>
    </div>
  );
}
