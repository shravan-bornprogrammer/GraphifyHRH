import { useEffect, useState } from "react";
import { ChevronDown, Loader2, Settings2 } from "lucide-react";
import { getAdminSettings, listLLMProviders, testLLM, updateAdminSettings } from "../api/client.js";

const PROVIDER_FIELDS = {
  ollama: [
    { key: "ollama_host", label: "Ollama host", placeholder: "http://localhost:11434" },
    { key: "ollama_model", label: "Model", placeholder: "mistral:7b" },
  ],
  openai: [
    { key: "openai_api_key", label: "API key", secret: true, placeholder: "sk-..." },
    { key: "openai_model", label: "Model", placeholder: "gpt-4o-mini" },
  ],
  anthropic: [
    { key: "anthropic_api_key", label: "API key", secret: true, placeholder: "sk-ant-..." },
    { key: "anthropic_model", label: "Model", placeholder: "claude-sonnet-4-6" },
  ],
  gemini: [
    { key: "gemini_api_key", label: "API key", secret: true, placeholder: "AIza..." },
    { key: "gemini_model", label: "Model", placeholder: "gemini-1.5-flash" },
  ],
  local: [
    { key: "local_base_url", label: "Base URL (OpenAI-compatible)", placeholder: "http://localhost:1234/v1" },
    { key: "local_model", label: "Model", placeholder: "local-model" },
    { key: "local_api_key", label: "API key (if required)", secret: true, placeholder: "not-needed" },
  ],
  none: [],
};

export default function AdminSettingsPanel() {
  const [open, setOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [settings, setSettings] = useState(null);
  const [providers, setProviders] = useState([]);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const [savedAt, setSavedAt] = useState(null);

  useEffect(() => {
    if (!open || loaded) return;
    Promise.all([getAdminSettings(), listLLMProviders()])
      .then(([s, p]) => {
        setSettings(s);
        setProviders(p.providers);
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
  }, [open, loaded]);

  const patchLLM = (key, value) => {
    setSettings((s) => ({ ...s, llm: { ...s.llm, [key]: value } }));
    setTestResult(null);
  };

  const save = async () => {
    setSaving(true);
    try {
      const updated = await updateAdminSettings({ llm: settings.llm, data_source: settings.data_source });
      setSettings(updated);
      setSavedAt(new Date());
    } catch (err) {
      alert("Could not save settings: " + err.message);
    } finally {
      setSaving(false);
    }
  };

  const runTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await testLLM({ provider: settings.llm.provider });
      setTestResult(res);
    } catch (err) {
      setTestResult({ ok: false, error: err.message });
    } finally {
      setTesting(false);
    }
  };

  if (!open) {
    return (
      <button className="btn btn-ghost admin-toggle" onClick={() => setOpen(true)}>
        <Settings2 size={15} />
        Admin settings
        <ChevronDown size={14} />
      </button>
    );
  }

  return (
    <div className="card admin-card">
      <div className="admin-card-head">
        <div>
          <div className="admin-card-eyebrow">Admin</div>
          <h3>LLM &amp; connection settings</h3>
          <p className="field-hint">
            Choose which model answers questions in the chat, and where source data comes from by
            default. Changes apply immediately — no restart needed.
          </p>
        </div>
        <button className="icon-btn" onClick={() => setOpen(false)} aria-label="Collapse">
          <ChevronDown size={16} style={{ transform: "rotate(180deg)" }} />
        </button>
      </div>

      {!loaded && (
        <div className="admin-loading">
          <Loader2 size={16} className="spin" /> Loading settings…
        </div>
      )}

      {loaded && settings && (
        <>
          <div className="field">
            <label>LLM provider</label>
            <select value={settings.llm.provider} onChange={(e) => patchLLM("provider", e.target.value)}>
              {providers.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.label} {p.configured ? "" : "(not configured)"}
                </option>
              ))}
            </select>
            <div className="field-hint">
              Used by the chat page to turn matched graph facts into a natural-language answer.
              Choose "None" to return raw graph facts with no LLM call.
            </div>
          </div>

          {PROVIDER_FIELDS[settings.llm.provider]?.length > 0 && (
            <div className="admin-provider-grid">
              {PROVIDER_FIELDS[settings.llm.provider].map((f) => (
                <div className="field" key={f.key}>
                  <label>{f.label}</label>
                  <input
                    type={f.secret ? "password" : "text"}
                    placeholder={f.placeholder}
                    value={settings.llm[f.key] || ""}
                    onChange={(e) => patchLLM(f.key, e.target.value)}
                  />
                </div>
              ))}
            </div>
          )}

          <div className="admin-actions">
            <button className="btn btn-subtle btn-sm" onClick={runTest} disabled={testing}>
              {testing ? <Loader2 size={13} className="spin" /> : null}
              Test connection
            </button>
            <button className="btn btn-primary btn-sm" onClick={save} disabled={saving}>
              {saving ? <Loader2 size={13} className="spin" /> : null}
              Save settings
            </button>
            {savedAt && <span className="admin-saved-note">Saved {savedAt.toLocaleTimeString()}</span>}
          </div>

          {testResult && (
            <div className={"admin-test-result " + (testResult.ok ? "ok" : "fail")}>
              {testResult.ok ? "✓ " + (testResult.reply || "Connection OK") : "✕ " + (testResult.error || "Failed")}
            </div>
          )}

          <hr className="admin-divider" />

          <div className="field">
            <label>Default extraction mode for new graphs</label>
            <select
              value={settings.extractor_default}
              onChange={(e) => setSettings((s) => ({ ...s, extractor_default: e.target.value }))}
            >
              <option value="spacy">spaCy (concepts, entities, people)</option>
              <option value="keybert">KeyBERT (short issue phrases)</option>
              <option value="both">Both</option>
              <option value="none">None (structured columns only)</option>
            </select>
          </div>
        </>
      )}
    </div>
  );
}
