import { forwardRef, useEffect, useMemo, useRef } from "react";
import ForceGraph2D from "react-force-graph-2d";

/**
 * Renders a knowledge-graph {nodes, edges} payload (the shape returned by
 * /api/graph/data and /api/graph/ask) as an interactive, zoomable,
 * clickable force-directed graph.
 *
 * Props:
 *  - data: { nodes: [{id,label,type,color}], edges: [{id,source,target,label}] }
 *  - highlightIds: Set of node ids to emphasize (others are dimmed)
 *  - onNodeClick(node)
 *  - selectedId: currently selected node id (drawn with a ring)
 */
const GraphCanvas = forwardRef(function GraphCanvas(
  { data, highlightIds, onNodeClick, selectedId, height = "100%" },
  outerRef
) {
  const fgRef = useRef();
  const hasHighlight = highlightIds && highlightIds.size > 0;

  const graphData = useMemo(() => {
    const nodes = (data?.nodes || []).map((n) => ({ ...n }));
    const nodeIds = new Set(nodes.map((n) => n.id));
    const links = (data?.edges || [])
      .filter((e) => nodeIds.has(e.source) && nodeIds.has(e.target))
      .map((e) => ({ ...e }));
    return { nodes, links };
  }, [data]);

  useEffect(() => {
    if (outerRef) outerRef.current = fgRef.current;
  }, [outerRef]);

  useEffect(() => {
    // Give the physics a moment then settle the camera on the graph.
    const t = setTimeout(() => {
      fgRef.current?.zoomToFit?.(500, 60);
    }, 350);
    return () => clearTimeout(t);
  }, [graphData]);

  return (
    <ForceGraph2D
      ref={fgRef}
      graphData={graphData}
      height={typeof height === "number" ? height : undefined}
      backgroundColor="rgba(0,0,0,0)"
      nodeRelSize={4}
      linkColor={(l) => (hasHighlight && (highlightIds.has(l.source?.id ?? l.source) || highlightIds.has(l.target?.id ?? l.target)) ? "#1f8a70" : "rgba(19,26,43,0.16)")}
      linkWidth={(l) =>
        hasHighlight && (highlightIds.has(l.source?.id ?? l.source) || highlightIds.has(l.target?.id ?? l.target)) ? 2 : 0.8
      }
      linkDirectionalArrowLength={4}
      linkDirectionalArrowRelPos={0.98}
      linkLabel={(l) => l.label || ""}
      nodeLabel={(n) => `${n.type}: ${n.label}`}
      onNodeClick={(n) => onNodeClick?.(n)}
      cooldownTicks={80}
      d3AlphaDecay={0.03}
      d3VelocityDecay={0.35}
      nodeCanvasObject={(node, ctx, globalScale) => {
        const isDim = hasHighlight && !highlightIds.has(node.id);
        const isSelected = node.id === selectedId;
        const baseR = 3.2 + Math.min(6, Math.sqrt(node.degree || 1));
        const r = isSelected ? baseR + 2 : baseR;

        ctx.globalAlpha = isDim ? 0.18 : 1;
        ctx.beginPath();
        ctx.arc(node.x, node.y, r, 0, 2 * Math.PI, false);
        ctx.fillStyle = node.color || "#8b93a3";
        ctx.fill();

        if (isSelected) {
          ctx.lineWidth = 1.6;
          ctx.strokeStyle = "#131a2b";
          ctx.stroke();
        }

        // Labels only render past a reasonable zoom level to avoid clutter.
        if (globalScale > 1.7 && !isDim) {
          const fontSize = Math.max(9.5, 11 / globalScale) * 1.6;
          ctx.font = `${fontSize}px Inter, sans-serif`;
          ctx.textAlign = "center";
          ctx.textBaseline = "top";
          ctx.fillStyle = "rgba(19,26,43,0.82)";
          const label = node.label.length > 26 ? node.label.slice(0, 24) + "…" : node.label;
          ctx.fillText(label, node.x, node.y + r + 2);
        }
        ctx.globalAlpha = 1;
      }}
    />
  );
});

export default GraphCanvas;
