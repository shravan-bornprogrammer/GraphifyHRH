# Nodal — HR Helpdesk Knowledge Graph (frontend)

A 3-page React app (Vite) for the Helpdesk Knowledge Graph API in
`../backend`:

1. **Data Source** (`/`) — upload Excel/CSV or connect a BigQuery table/query;
   map columns to graph roles (id / hierarchy / attribute / free text);
   configure the LLM provider and data-source defaults from **Admin
   Settings**; build the knowledge graph.
2. **Graph Explorer** (`/explore`) — the graph rendered as an interactive,
   zoomable, force-directed canvas. Search highlights matching nodes, a
   legend lets you filter by node type, and clicking a node opens a detail
   panel with its immediate connections.
3. **Ask the Graph** (`/chat`) — a chat interface backed by the graph
   ("GraphRAG"): each answer is shown next to the exact subgraph of nodes
   and edges that grounded it.

## Setup

```bash
npm install
cp .env.example .env   # point VITE_BACKEND_ORIGIN at your running backend
npm run dev             # http://localhost:5173
```

The dev server proxies `/api/*` to `VITE_BACKEND_ORIGIN` (default
`http://localhost:8000`), so make sure the FastAPI backend
(`../backend`, `python run.py`) is running first.

## Build

```bash
npm run build     # outputs to dist/
npm run preview   # serve the production build locally
```

For a production deployment, either serve `dist/` behind a reverse proxy
that forwards `/api/*` to the FastAPI backend (recommended — keeps the
same-origin relative API calls working unchanged), or set
`VITE_API_BASE_URL` at build time to call the backend's absolute URL from
a different origin (make sure `CORS_ORIGINS` on the backend allows it).

## Stack

- React 19 + Vite + react-router-dom
- `react-force-graph-2d` for the interactive graph canvas (search
  highlighting, type filtering, click-to-inspect)
- axios for the API client (`src/api/client.js`)
- Plain CSS with a small design-token system (`src/index.css`) — no UI
  framework dependency

## Project layout

```
src/
  api/client.js              Typed wrapper around every backend endpoint
  context/SessionContext.jsx Global session state (active dataset/graph),
                              persisted to sessionStorage
  components/
    AppShell.jsx              Left-rail navigation + status
    AdminSettingsPanel.jsx    LLM provider + data source admin form
    ColumnMapper.jsx           Column-role assignment table
    GraphCanvas.jsx            react-force-graph-2d wrapper (shared by
                                Graph Explorer & Chat)
    GraphLegend.jsx            Node-type color legend / filter chips
    NodeDetailPanel.jsx        Click-a-node side panel
  pages/
    SetupPage.jsx               Page 1
    GraphExplorerPage.jsx       Page 2
    ChatPage.jsx                 Page 3
```
