"""
Central configuration for the Helpdesk Knowledge Graph API.

Everything is overridable via environment variables (or a `.env` file),
so the service can be pointed at different storage locations / LLM
providers without touching code.
"""
from __future__ import annotations

import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # python-dotenv is optional; env vars can still be set by the shell.
    pass


class Settings:
    # --- Storage -----------------------------------------------------
    BASE_DIR: Path = Path(__file__).resolve().parent.parent
    STORAGE_DIR: Path = Path(os.getenv("STORAGE_DIR", BASE_DIR / "storage"))
    UPLOAD_DIR: Path = STORAGE_DIR / "uploads"
    GRAPH_DIR: Path = STORAGE_DIR / "graphs"
    HTML_DIR: Path = STORAGE_DIR / "html"

    # Max upload size (bytes). Default 25 MB.
    MAX_UPLOAD_BYTES: int = int(os.getenv("MAX_UPLOAD_BYTES", 25 * 1024 * 1024))

    # How long an in-memory/on-disk session is kept before it's eligible
    # for cleanup (minutes). 0 = never expire automatically.
    SESSION_TTL_MINUTES: int = int(os.getenv("SESSION_TTL_MINUTES", 240))

    # --- NLP / extraction ---------------------------------------------
    SPACY_MODEL: str = os.getenv("SPACY_MODEL", "en_core_web_sm")
    EMBEDDING_MODEL: str = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
    CANONICALIZE_DISTANCE_THRESHOLD: float = float(
        os.getenv("CANONICALIZE_DISTANCE_THRESHOLD", 0.35)
    )

    # --- LLM provider for the /ask endpoint ----------------------------
    # One of: "ollama", "openai", "anthropic", "none"
    LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "ollama")
    OLLAMA_HOST: str = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    OLLAMA_MODEL: str = os.getenv("OLLAMA_MODEL", "mistral:7b")
    OPENAI_API_KEY: str | None = os.getenv("OPENAI_API_KEY")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    ANTHROPIC_API_KEY: str | None = os.getenv("ANTHROPIC_API_KEY")
    ANTHROPIC_MODEL: str = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")

    # --- CORS -----------------------------------------------------------
    CORS_ORIGINS: list[str] = os.getenv("CORS_ORIGINS", "*").split(",")

    def ensure_dirs(self) -> None:
        for d in (self.UPLOAD_DIR, self.GRAPH_DIR, self.HTML_DIR):
            d.mkdir(parents=True, exist_ok=True)


settings = Settings()
settings.ensure_dirs()
