"""
Graph-grounded Q&A ("GraphRAG"), generalized from the notebook's
`find_matching_nodes` / `get_context_subgraph` / `ask_hr_bot`.

The matching/subgraph logic is schema-agnostic already (it just does
substring matching over node labels), so it needed no changes to work on
any Excel. What was hard-coded was the LLM call (`ollama.chat(model="mistral:7b")`);
that's now pluggable via LLM_PROVIDER (ollama / openai / anthropic / none)
so the service can run against a local model or a hosted API.
"""
from __future__ import annotations

import re

import networkx as nx

from ..config import settings

SYSTEM_PROMPT = (
    "You are a helpdesk root-cause analysis assistant. Answer ONLY using "
    "the knowledge graph facts given to you. If the answer isn't supported "
    "by the facts, say so plainly. Be concise and specific (name issues, "
    "people, categories mentioned in the facts)."
)


def find_matching_nodes(graph: nx.MultiDiGraph, question: str) -> list[str]:
    q = question.lower()
    matches = []
    for n, data in graph.nodes(data=True):
        label = str(data.get("label", n)).lower()
        clean = re.sub(r"^[a-z ]+:", "", label)
        if clean and (clean in q or any(w in q for w in clean.split() if len(w) > 3)):
            matches.append(n)
    return matches


def get_context_subgraph(graph: nx.MultiDiGraph, matched_nodes: list[str], radius: int = 2):
    nodes: set[str] = set()
    undirected = graph.to_undirected(as_view=True)
    for n in matched_nodes:
        nodes |= set(nx.ego_graph(undirected, n, radius=radius).nodes())
    return graph.subgraph(nodes)


def subgraph_to_facts(sub: nx.MultiDiGraph, max_facts: int = 80) -> list[str]:
    facts = []
    for u, v, data in sub.edges(data=True):
        label = data.get("label", data.get("relation", ""))
        facts.append(f"{u} --{label}--> {v}")
    return facts[:max_facts]


def _call_ollama(prompt: str, model: str | None) -> str:
    import ollama

    response = ollama.Client(host=settings.OLLAMA_HOST).chat(
        model=model or settings.OLLAMA_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return response["message"]["content"]


def _call_openai(prompt: str, model: str | None) -> str:
    from openai import OpenAI

    client = OpenAI(api_key=settings.OPENAI_API_KEY)
    response = client.chat.completions.create(
        model=model or settings.OPENAI_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )
    return response.choices[0].message.content or ""


def _call_anthropic(prompt: str, model: str | None) -> str:
    import anthropic

    client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
    response = client.messages.create(
        model=model or settings.ANTHROPIC_MODEL,
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text")


def _complete(prompt: str, model: str | None = None) -> str:
    provider = settings.LLM_PROVIDER.lower()
    if provider == "ollama":
        return _call_ollama(prompt, model)
    if provider == "openai":
        return _call_openai(prompt, model)
    if provider == "anthropic":
        return _call_anthropic(prompt, model)
    raise RuntimeError(
        f"LLM_PROVIDER={settings.LLM_PROVIDER!r} has no answering backend configured "
        "(set it to 'ollama', 'openai', or 'anthropic')."
    )


def ask_graph(
    graph: nx.MultiDiGraph,
    question: str,
    radius: int = 2,
    max_facts: int = 80,
    model: str | None = None,
) -> tuple[str, list[str], list[str]]:
    """Returns (answer, matched_node_ids, facts)."""
    matched = find_matching_nodes(graph, question)
    if not matched:
        return (
            "I couldn't find related nodes in the graph for that question.",
            [],
            [],
        )

    sub = get_context_subgraph(graph, matched, radius=radius)
    facts = subgraph_to_facts(sub, max_facts=max_facts)
    context = "\n".join(facts)

    prompt = (
        f"Knowledge graph facts:\n{context}\n\nQuestion: {question}\nAnswer:"
    )

    if settings.LLM_PROVIDER.lower() == "none":
        answer = (
            "LLM_PROVIDER is set to 'none', so no natural-language answer was "
            f"generated. Here are the {len(facts)} matching graph facts instead."
        )
    else:
        answer = _complete(prompt, model)

    return answer, matched, facts
