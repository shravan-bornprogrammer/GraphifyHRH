"""Pydantic schemas for requests/responses."""
from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field


class ColumnProfile(BaseModel):
    name: str
    dtype: str
    n_unique: int
    n_missing: int
    sample_values: list[Any]
    suggested_role: Literal[
        "id", "hierarchy", "attribute", "text", "ignore"
    ]


class UploadResponse(BaseModel):
    session_id: str
    filename: str
    n_rows: int
    n_columns: int
    columns: list[ColumnProfile]
    preview: list[dict[str, Any]]
    message: str = (
        "File loaded. Review `columns[].suggested_role`, then POST the "
        "mapping you want to /api/graph/build."
    )


class GraphBuildRequest(BaseModel):
    session_id: str

    # Dynamic column mapping — every field is optional so the endpoint
    # works on literally any spreadsheet shape.
    id_column: Optional[str] = Field(
        default=None,
        description="Column holding a unique row/ticket id. Auto-generated if omitted.",
    )
    hierarchy_columns: list[str] = Field(
        default_factory=list,
        description=(
            "Ordered categorical columns that form a parent->child chain, "
            "e.g. ['Category','Topic','Subtopic']. Leave empty to skip."
        ),
    )
    attribute_columns: list[str] = Field(
        default_factory=list,
        description=(
            "Other categorical columns to attach directly to each row-node, "
            "e.g. ['Intent','Sentiment']."
        ),
    )
    text_columns: list[str] = Field(
        default_factory=list,
        description="Free-text columns to run NLP extraction over (e.g. feedback/comments).",
    )
    extractor: Literal["spacy", "keybert", "both", "none"] = "spacy"
    canonicalize: bool = Field(
        default=False,
        description="Cluster near-duplicate extracted phrases into a single canonical label "
        "(requires sentence-transformers + scikit-learn).",
    )
    extract_people: bool = True

    node_label_column: Optional[str] = Field(
        default=None,
        description="Column to use as the human-readable label for each row-node "
        "(defaults to id_column, or the row index).",
    )


class GraphBuildResponse(BaseModel):
    session_id: str
    n_nodes: int
    n_edges: int
    node_types: dict[str, int]
    view_url: str
    message: str


class AskRequest(BaseModel):
    session_id: str
    question: str
    radius: int = 2
    max_facts: int = 80
    model: Optional[str] = None


class AskResponse(BaseModel):
    question: str
    answer: str
    matched_nodes: list[str]
    facts: list[str]
    subgraph_view_url: Optional[str] = None


class SessionInfo(BaseModel):
    session_id: str
    filename: str
    created_at: str
    has_graph: bool
    n_rows: int


class ErrorResponse(BaseModel):
    detail: str
