"""
Helpdesk Knowledge Graph API
============================

A FastAPI service that turns the original "Helpdesk_POC.ipynb" notebook
into a reusable HTTP API that works on **any** Excel/CSV file, not just the
fixed Ticket/Category/Topic/Subtopic/Intent/Sentiment schema the notebook
hard-coded.

Typical flow:
  1. POST /api/upload            -> upload a spreadsheet, get back a
                                     session_id + per-column profile with a
                                     suggested role for each column.
  2. POST /api/graph/build       -> tell the API which columns are the
                                     hierarchy / attributes / free text,
                                     it builds a NetworkX knowledge graph.
  3. GET  /api/graph/view/{id}   -> interactive, searchable HTML graph.
  4. POST /api/graph/ask         -> ask a natural-language question,
                                     answered from the graph (GraphRAG).

Run with:  uvicorn app.main:app --reload
"""
from __future__ import annotations

import logging

from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from .config import settings
from .models import (
    AskRequest,
    AskResponse,
    ErrorResponse,
    GraphBuildRequest,
    GraphBuildResponse,
    SessionInfo,
    UploadResponse,
)
from .services import data_loader, graph_builder, graph_viz, llm_qa
from .storage import store

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("helpdesk_graph_api")

app = FastAPI(
    title="Helpdesk Knowledge Graph API",
    description=__doc__,
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health", tags=["meta"])
def health() -> dict:
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# 1. Upload any spreadsheet
# ---------------------------------------------------------------------------
@app.post(
    "/api/upload",
    response_model=UploadResponse,
    responses={400: {"model": ErrorResponse}},
    tags=["data"],
)
async def upload_file(
    file: UploadFile = File(...),
    sheet_name: str | None = Query(
        default=None, description="Sheet name/index for multi-sheet Excel files."
    ),
) -> UploadResponse:
    raw = await file.read()
    if len(raw) > settings.MAX_UPLOAD_BYTES:
        raise HTTPException(413, f"File exceeds max size of {settings.MAX_UPLOAD_BYTES} bytes.")

    sheet: str | int | None = sheet_name
    if sheet_name is not None and sheet_name.isdigit():
        sheet = int(sheet_name)

    try:
        df = data_loader.load_spreadsheet(file.filename or "upload.xlsx", raw, sheet_name=sheet or 0)
    except Exception as exc:
        logger.exception("Failed to parse uploaded file")
        raise HTTPException(400, f"Could not parse '{file.filename}' as a spreadsheet: {exc}") from exc

    if df.empty:
        raise HTTPException(400, "The uploaded file has no usable rows/columns.")

    session = store.create(filename=file.filename or "upload.xlsx", df=df)
    columns = data_loader.profile_columns(df)

    return UploadResponse(
        session_id=session.session_id,
        filename=session.filename,
        n_rows=len(df),
        n_columns=len(df.columns),
        columns=columns,
        preview=data_loader.preview_rows(df),
    )


@app.get("/api/upload/{session_id}/sheets", tags=["data"])
async def list_sheets(session_id: str) -> dict:
    """Convenience endpoint if you need to re-inspect available sheets of an original file."""
    path = settings.UPLOAD_DIR / f"{session_id}.pkl"
    if not path.exists():
        raise HTTPException(404, "Unknown session_id.")
    return {"note": "Re-upload with ?sheet_name=<name> to load a specific sheet."}


# ---------------------------------------------------------------------------
# 2. Build the knowledge graph from a dynamic column mapping
# ---------------------------------------------------------------------------
@app.post(
    "/api/graph/build",
    response_model=GraphBuildResponse,
    responses={404: {"model": ErrorResponse}, 400: {"model": ErrorResponse}},
    tags=["graph"],
)
def build_graph(req: GraphBuildRequest) -> GraphBuildResponse:
    try:
        session = store.get(req.session_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc

    all_requested = set(req.hierarchy_columns) | set(req.attribute_columns) | set(req.text_columns)
    unknown = all_requested - set(session.df.columns)
    if unknown:
        raise HTTPException(400, f"Unknown column(s): {sorted(unknown)}")

    try:
        graph, node_type_counts = graph_builder.build_graph(session.df, req)
    except Exception as exc:
        logger.exception("Graph build failed")
        raise HTTPException(400, f"Failed to build graph: {exc}") from exc

    store.set_graph(req.session_id, graph, meta=req.model_dump())

    # Persist a static HTML view right away so /api/graph/view is instant.
    html = graph_viz.render_graph_html(graph, title=f"Knowledge Graph — {session.filename}")
    (settings.HTML_DIR / f"{req.session_id}.html").write_text(html, encoding="utf-8")

    return GraphBuildResponse(
        session_id=req.session_id,
        n_nodes=graph.number_of_nodes(),
        n_edges=graph.number_of_edges(),
        node_types=node_type_counts,
        view_url=f"/api/graph/view/{req.session_id}",
        message="Graph built. Open view_url in a browser for the interactive, searchable graph.",
    )


# ---------------------------------------------------------------------------
# 3. Interactive HTML view
# ---------------------------------------------------------------------------
@app.get(
    "/api/graph/view/{session_id}",
    response_class=HTMLResponse,
    responses={404: {"model": ErrorResponse}},
    tags=["graph"],
)
def view_graph(session_id: str) -> HTMLResponse:
    try:
        session = store.get(session_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc
    if session.graph is None:
        raise HTTPException(404, "No graph built yet for this session. POST /api/graph/build first.")

    cached = settings.HTML_DIR / f"{session_id}.html"
    if cached.exists():
        return HTMLResponse(cached.read_text(encoding="utf-8"))

    html = graph_viz.render_graph_html(session.graph, title=f"Knowledge Graph — {session.filename}")
    return HTMLResponse(html)


# ---------------------------------------------------------------------------
# 4. Graph-grounded Q&A
# ---------------------------------------------------------------------------
@app.post(
    "/api/graph/ask",
    response_model=AskResponse,
    responses={404: {"model": ErrorResponse}, 400: {"model": ErrorResponse}},
    tags=["graph"],
)
def ask(req: AskRequest) -> AskResponse:
    try:
        session = store.get(req.session_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc
    if session.graph is None:
        raise HTTPException(404, "No graph built yet for this session. POST /api/graph/build first.")

    try:
        answer, matched, facts = llm_qa.ask_graph(
            session.graph, req.question, radius=req.radius, max_facts=req.max_facts, model=req.model
        )
    except Exception as exc:
        logger.exception("Q&A failed")
        raise HTTPException(400, f"Failed to answer question: {exc}") from exc

    subgraph_view_url = None
    if matched:
        sub = llm_qa.get_context_subgraph(session.graph, matched, radius=req.radius)
        html = graph_viz.render_graph_html(
            session.graph, title=f"Answer subgraph — {req.question}", subset_nodes=list(sub.nodes())
        )
        fname = f"{req.session_id}_answer.html"
        (settings.HTML_DIR / fname).write_text(html, encoding="utf-8")
        subgraph_view_url = f"/api/graph/view-static/{fname}"

    return AskResponse(
        question=req.question,
        answer=answer,
        matched_nodes=matched,
        facts=facts,
        subgraph_view_url=subgraph_view_url,
    )


@app.get("/api/graph/view-static/{fname}", response_class=HTMLResponse, tags=["graph"])
def view_static(fname: str) -> HTMLResponse:
    path = settings.HTML_DIR / fname
    if not path.exists() or "/" in fname or ".." in fname:
        raise HTTPException(404, "Not found.")
    return HTMLResponse(path.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# 5. Session management
# ---------------------------------------------------------------------------
@app.get("/api/sessions", response_model=list[SessionInfo], tags=["sessions"])
def list_sessions() -> list[SessionInfo]:
    return [
        SessionInfo(
            session_id=s.session_id,
            filename=s.filename,
            created_at=s.created_at.isoformat(),
            has_graph=s.graph is not None,
            n_rows=len(s.df),
        )
        for s in store.list_sessions()
    ]


@app.delete("/api/sessions/{session_id}", tags=["sessions"])
def delete_session(session_id: str) -> dict:
    store.delete(session_id)
    return {"deleted": session_id}
